package com.example.omnigestion.ui.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.omnigestion.ui.screens.audit.AuditLogsScreen
import com.example.omnigestion.ui.screens.auth.LoginScreen
import com.example.omnigestion.ui.screens.clientportal.ClientPortalScreen
import com.example.omnigestion.ui.screens.dashboard.DashboardScreen
import com.example.omnigestion.ui.screens.debtors.DebtorsScreen
import com.example.omnigestion.ui.screens.employees.EmployeesScreen
import com.example.omnigestion.ui.screens.finances.FinancesScreen
import com.example.omnigestion.ui.screens.inventory.InventoryScreen
import com.example.omnigestion.ui.screens.inventory.RecountAuditScreen
import com.example.omnigestion.ui.screens.inventory.StockTransferScreen
import com.example.omnigestion.ui.screens.pos.PosScreen
import com.example.omnigestion.ui.screens.reports.ReportsScreen
import com.example.omnigestion.ui.screens.sales.SalesHistoryScreen
import com.example.omnigestion.ui.screens.settings.SettingsScreen
import com.example.omnigestion.ui.viewmodel.AppScreen
import com.example.omnigestion.ui.viewmodel.OmniViewModel

object Routes {
    const val LOGIN = "login"
    const val DASHBOARD = "dashboard"
    const val POS = "pos"
    const val INVENTORY = "inventory"
    const val RECOUNT_AUDIT = "recount_audit"
    const val TRANSFERS = "transfers"
    const val EMPLOYEES = "employees"
    const val DEBTORS = "debtors"
    const val FINANCES = "finances"
    const val AUDIT_LOGS = "audit_logs"
    const val SALES_HISTORY = "sales_history"
    const val REPORTS = "reports"
    const val CLIENT_PORTAL = "client_portal"
    const val SETTINGS = "settings"

    fun fromAppScreen(screen: AppScreen): String = when (screen) {
        AppScreen.LOGIN -> LOGIN
        AppScreen.DASHBOARD -> DASHBOARD
        AppScreen.POS -> POS
        AppScreen.INVENTORY -> INVENTORY
        AppScreen.RECOUNT_AUDIT -> RECOUNT_AUDIT
        AppScreen.TRANSFERS -> TRANSFERS
        AppScreen.EMPLOYEES -> EMPLOYEES
        AppScreen.DEBTORS -> DEBTORS
        AppScreen.FINANCES -> FINANCES
        AppScreen.AUDIT_LOGS -> AUDIT_LOGS
        AppScreen.SALES_HISTORY -> SALES_HISTORY
        AppScreen.REPORTS -> REPORTS
        AppScreen.CLIENT_PORTAL -> CLIENT_PORTAL
        AppScreen.SETTINGS -> SETTINGS
    }

    fun toAppScreen(route: String?): AppScreen = when (route) {
        LOGIN -> AppScreen.LOGIN
        DASHBOARD -> AppScreen.DASHBOARD
        POS -> AppScreen.POS
        INVENTORY -> AppScreen.INVENTORY
        RECOUNT_AUDIT -> AppScreen.RECOUNT_AUDIT
        TRANSFERS -> AppScreen.TRANSFERS
        EMPLOYEES -> AppScreen.EMPLOYEES
        DEBTORS -> AppScreen.DEBTORS
        FINANCES -> AppScreen.FINANCES
        AUDIT_LOGS -> AppScreen.AUDIT_LOGS
        SALES_HISTORY -> AppScreen.SALES_HISTORY
        REPORTS -> AppScreen.REPORTS
        CLIENT_PORTAL -> AppScreen.CLIENT_PORTAL
        SETTINGS -> AppScreen.SETTINGS
        else -> AppScreen.DASHBOARD
    }
}

@Composable
fun AppNavigation(
    navController: NavHostController,
    viewModel: OmniViewModel,
    modifier: Modifier = Modifier
) {
    val initialRoute = remember {
        val user = viewModel.currentUser.value
        if (user != null) {
            if (viewModel.currentRole.value == com.example.omnigestion.data.model.RoleType.ADMIN) Routes.DASHBOARD else Routes.POS
        } else {
            Routes.LOGIN
        }
    }

    NavHost(
        navController = navController,
        startDestination = initialRoute,
        modifier = modifier,
        enterTransition = { fadeIn() },
        exitTransition = { fadeOut() },
        popEnterTransition = { fadeIn() },
        popExitTransition = { fadeOut() }
    ) {
        composable(Routes.LOGIN) {
            LoginScreen(
                viewModel = viewModel,
                onLoginSuccess = { targetRoute ->
                    navController.navigate(targetRoute) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                },
                onOpenClientPortal = {
                    navController.navigate(Routes.CLIENT_PORTAL)
                }
            )
        }
        composable(Routes.DASHBOARD) {
            DashboardScreen(viewModel = viewModel, onNavigate = { navController.navigate(it) })
        }
        composable(Routes.POS) {
            PosScreen(viewModel = viewModel)
        }
        composable(Routes.INVENTORY) {
            InventoryScreen(viewModel = viewModel, onNavigate = { navController.navigate(it) })
        }
        composable(Routes.RECOUNT_AUDIT) {
            RecountAuditScreen(viewModel = viewModel)
        }
        composable(Routes.TRANSFERS) {
            StockTransferScreen(viewModel = viewModel)
        }
        composable(Routes.EMPLOYEES) {
            EmployeesScreen(viewModel = viewModel)
        }
        composable(Routes.DEBTORS) {
            DebtorsScreen(viewModel = viewModel)
        }
        composable(Routes.FINANCES) {
            FinancesScreen(viewModel = viewModel)
        }
        composable(Routes.AUDIT_LOGS) {
            AuditLogsScreen(viewModel = viewModel)
        }
        composable(Routes.SALES_HISTORY) {
            SalesHistoryScreen(viewModel = viewModel)
        }
        composable(Routes.REPORTS) {
            ReportsScreen(viewModel = viewModel)
        }
        composable(Routes.CLIENT_PORTAL) {
            ClientPortalScreen(viewModel = viewModel, onOpenLogin = { navController.navigate(Routes.LOGIN) })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(viewModel = viewModel)
        }
    }
}
