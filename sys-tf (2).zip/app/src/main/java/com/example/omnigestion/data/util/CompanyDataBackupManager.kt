package com.example.omnigestion.data.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.omnigestion.data.local.AppDatabase
import com.example.omnigestion.data.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object CompanyDataBackupManager {
    /**
     * Genera un archivo JSON de respaldo absoluto con toda la información de la empresa:
     * Inventario, Ventas, Finanzas, Clientes y Deudas, Historial de Auditoría, Compras, etc.
     */
    suspend fun generateCompleteCompanyBackup(
        context: Context,
        database: AppDatabase
    ): Pair<File, String> {
        val root = JSONObject()
        val now = Date()
        val dateIso = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(now)
        val fileStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(now)

        root.put("sistema", "SYS-TF ERP & POS")
        root.put("tipo_archivo", "RESPALDO_TOTAL_EMPRESA")
        root.put("version_esquema", 1)
        root.put("fecha_generacion", dateIso)
        root.put("timestamp", now.time)

        // 1. Configuración de la Empresa
        val settings = database.settingsDao().getSettingsSync() ?: BusinessSettings()
        val settingsObj = JSONObject().apply {
            put("id", settings.id)
            put("businessName", settings.businessName)
            put("taxId", settings.taxId)
            put("phone", settings.phone)
            put("email", settings.email)
            put("address", settings.address)
            put("bankName", settings.bankName)
            put("bankAccount", settings.bankAccount)
            put("qrHolderName", settings.qrHolderName)
            put("logoUrl", settings.logoUrl)
            put("slogan", settings.slogan)
            put("currencySymbol", settings.currencySymbol)
            put("taxPercentage", settings.taxPercentage)
            put("invoicePrefix", settings.invoicePrefix)
            put("receiptFooterMessage", settings.receiptFooterMessage)
            put("lowStockThreshold", settings.lowStockThreshold)
            put("soundAlertsEnabled", settings.soundAlertsEnabled)
        }
        root.put("configuracion_empresa", settingsObj)

        // 2. Inventario Completo de Productos
        val products = database.productDao().getAllProductsSync()
        val productsArray = JSONArray()
        for (p in products) {
            val pObj = JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("codigo", p.sku)
                put("category", p.category)
                put("costPrice", p.costPrice)
                put("salePrice", p.salePrice)
                put("stockQuantity", p.stockQuantity)
                put("minStock", p.minStock)
                put("imageUrl", p.imageUrl)
                put("description", p.description)
            }
            productsArray.put(pObj)
        }
        root.put("inventario_productos", productsArray)

        // 3. Ventas y Facturación
        val sales = database.saleDao().getAllSalesSync()
        val salesArray = JSONArray()
        for (s in sales) {
            val sObj = JSONObject().apply {
                put("id", s.id)
                put("saleNumber", s.saleNumber)
                put("customerId", s.customerId)
                put("customerName", s.customerName)
                put("totalAmount", s.totalAmount)
                put("paymentMethod", s.paymentMethod)
                put("paymentStatus", s.paymentStatus)
                put("timestamp", s.timestamp)
                put("employeeId", s.employeeId)
                put("employeeName", s.employeeName)
                put("currency", s.currency)
                put("warehouseId", s.warehouseId)
                put("notes", s.notes)
            }
            salesArray.put(sObj)
        }
        root.put("ventas", salesArray)

        // 4. Detalle de Ítems de Venta
        val saleItems = database.saleDao().getAllSaleItemsSync()
        val saleItemsArray = JSONArray()
        for (item in saleItems) {
            val itemObj = JSONObject().apply {
                put("id", item.id)
                put("saleId", item.saleId)
                put("productId", item.productId)
                put("productName", item.productName)
                put("quantity", item.quantity)
                put("unitPrice", item.unitPrice)
                put("costPrice", item.costPrice)
                put("subtotal", item.subtotal)
            }
            saleItemsArray.put(itemObj)
        }
        root.put("items_ventas", saleItemsArray)

        // 5. Finanzas y Gastos
        val expenses = database.expenseDao().getAllExpensesSync()
        val expensesArray = JSONArray()
        for (e in expenses) {
            val eObj = JSONObject().apply {
                put("id", e.id)
                put("category", e.category)
                put("description", e.description)
                put("amount", e.amount)
                put("date", e.date)
                put("timestamp", e.timestamp)
                put("employeeId", e.employeeId)
                put("employeeName", e.employeeName)
                put("isProductPurchase", e.isProductPurchase)
                put("purchaseItemsDetails", e.purchaseItemsDetails)
                put("receiptUrl", e.receiptUrl ?: "")
            }
            expensesArray.put(eObj)
        }
        root.put("finanzas_gastos", expensesArray)

        // 6. Clientes y Deudas
        val customers = database.customerDao().getAllCustomersSync()
        val customersArray = JSONArray()
        for (c in customers) {
            val cObj = JSONObject().apply {
                put("id", c.id)
                put("name", c.name)
                put("phone", c.phone)
                put("email", c.email)
                put("address", c.address)
                put("currentDebt", c.currentDebt)
                put("creditLimit", c.creditLimit)
                put("notes", c.notes)
            }
            customersArray.put(cObj)
        }
        root.put("clientes_deudores", customersArray)

        // 7. Pagos y Abonos de Deudas
        val payments = database.customerPaymentDao().getAllPaymentsSync()
        val paymentsArray = JSONArray()
        for (pay in payments) {
            val payObj = JSONObject().apply {
                put("id", pay.id)
                put("customerId", pay.customerId)
                put("customerName", pay.customerName)
                put("amount", pay.amount)
                put("timestamp", pay.timestamp)
                put("paymentMethod", pay.paymentMethod)
                put("notes", pay.notes)
            }
            paymentsArray.put(payObj)
        }
        root.put("pagos_abonos_deudas", paymentsArray)

        // 8. Pedidos de Compra a Proveedores
        val purchaseOrders = database.purchaseOrderDao().getAllOrdersSync()
        val poArray = JSONArray()
        for (po in purchaseOrders) {
            val poObj = JSONObject().apply {
                put("id", po.id)
                put("orderNumber", po.orderNumber)
                put("supplierName", po.supplierName)
                put("supplierPhone", po.supplierPhone)
                put("timestamp", po.timestamp)
                put("dateStr", po.dateStr)
                put("itemsCount", po.itemsCount)
                put("totalUnits", po.totalUnits)
                put("estimatedTotalCost", po.estimatedTotalCost)
                put("status", po.status)
                put("createdByEmployeeName", po.createdByEmployeeName)
                put("notes", po.notes)
            }
            poArray.put(poObj)
        }
        root.put("pedidos_compra", poArray)

        val poItems = database.purchaseOrderDao().getAllPurchaseOrderItemsSync()
        val poItemsArray = JSONArray()
        for (item in poItems) {
            val itObj = JSONObject().apply {
                put("id", item.id)
                put("orderId", item.orderId)
                put("productId", item.productId)
                put("productName", item.productName)
                put("quantity", item.quantity)
                put("estimatedUnitCost", item.estimatedUnitCost)
                put("subtotal", item.subtotal)
            }
            poItemsArray.put(itObj)
        }
        root.put("items_pedidos_compra", poItemsArray)

        // 9. Almacenes y Transferencias
        val warehouses = database.warehouseDao().getAllWarehousesSync()
        val whArray = JSONArray()
        for (w in warehouses) {
            val wObj = JSONObject().apply {
                put("id", w.id)
                put("name", w.name)
                put("location", w.location)
                put("isDefault", w.isDefault)
            }
            whArray.put(wObj)
        }
        root.put("almacenes", whArray)

        val transfers = database.stockTransferDao().getAllTransfersSync()
        val trArray = JSONArray()
        for (tr in transfers) {
            val trObj = JSONObject().apply {
                put("id", tr.id)
                put("transferNumber", tr.transferNumber)
                put("sourceWarehouseId", tr.sourceWarehouseId)
                put("sourceWarehouseName", tr.sourceWarehouseName)
                put("targetWarehouseId", tr.targetWarehouseId)
                put("targetWarehouseName", tr.targetWarehouseName)
                put("timestamp", tr.timestamp)
                put("dateStr", tr.dateStr)
                put("itemsCount", tr.itemsCount)
                put("totalUnits", tr.totalUnits)
                put("status", tr.status)
                put("performedByEmployeeName", tr.performedByEmployeeName)
                put("notes", tr.notes)
            }
            trArray.put(trObj)
        }
        root.put("transferencias_almacen", trArray)

        val trItems = database.stockTransferDao().getAllTransferItemsSync()
        val trItemsArray = JSONArray()
        for (item in trItems) {
            val itObj = JSONObject().apply {
                put("id", item.id)
                put("transferId", item.transferId)
                put("productId", item.productId)
                put("productName", item.productName)
                put("quantity", item.quantity)
            }
            trItemsArray.put(itObj)
        }
        root.put("items_transferencias", trItemsArray)

        // 10. Empleados
        val employees = database.employeeDao().getAllEmployeesSync()
        val empArray = JSONArray()
        for (emp in employees) {
            val empObj = JSONObject().apply {
                put("id", emp.id)
                put("fullName", emp.fullName)
                put("email", emp.email)
                put("phone", emp.phone)
                put("address", emp.address)
                put("role", emp.role)
                put("baseSalary", emp.baseSalary)
                put("commissionRate", emp.commissionRate)
            }
            empArray.put(empObj)
        }
        root.put("empleados", empArray)

        // 11. Asistencias
        val attendances = database.attendanceDao().getAllAttendancesSync()
        val attArray = JSONArray()
        for (att in attendances) {
            val attObj = JSONObject().apply {
                put("id", att.id)
                put("employeeId", att.employeeId)
                put("employeeName", att.employeeName)
                put("checkInTime", att.checkInTime)
                put("checkOutTime", att.checkOutTime ?: -1)
                put("dateStr", att.dateStr)
                put("hoursWorked", att.hoursWorked)
                put("notes", att.notes)
            }
            attArray.put(attObj)
        }
        root.put("asistencias", attArray)

        // 12. Historial de Auditoría
        val logs = database.auditLogDao().getAllAuditLogsSync()
        val logsArray = JSONArray()
        for (l in logs) {
            val lObj = JSONObject().apply {
                put("id", l.id)
                put("timestamp", l.timestamp)
                put("dateFormatted", l.dateFormatted)
                put("userEmail", l.userEmail)
                put("userName", l.userName)
                put("userRole", l.userRole)
                put("actionType", l.actionType)
                put("entityId", l.entityId)
                put("description", l.description)
                put("previousValue", l.previousValue)
                put("newValue", l.newValue)
            }
            logsArray.put(lObj)
        }
        root.put("historial_auditoria", logsArray)

        // Resumen Estadístico
        val summaryObj = JSONObject().apply {
            put("total_articulos_inventario", products.size)
            put("total_unidades_stock", products.sumOf { it.stockQuantity })
            put("valor_costo_inventario", products.sumOf { it.costPrice * it.stockQuantity })
            put("valor_venta_inventario", products.sumOf { it.salePrice * it.stockQuantity })
            put("total_ventas_registradas", sales.size)
            put("monto_total_ventas", sales.sumOf { it.totalAmount })
            put("total_gastos_registrados", expenses.size)
            put("monto_total_gastos", expenses.sumOf { it.amount })
            put("total_clientes", customers.size)
            put("deuda_total_acumulada", customers.sumOf { it.currentDebt })
            put("total_pedidos_compra", purchaseOrders.size)
            put("total_registros_auditoria", logs.size)
        }
        root.put("resumen_general", summaryObj)

        val jsonString = root.toString(2)
        val fileName = "Respaldo_Completo_SYS_TF_${fileStamp}.json"
        val file = File(context.cacheDir, fileName)
        FileOutputStream(file).use { out ->
            out.write(jsonString.toByteArray(Charsets.UTF_8))
        }
        return Pair(file, jsonString)
    }

    fun shareBackupFile(context: Context, file: File) {
        try {
            val uri = try {
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
            } catch (e: Exception) {
                Uri.fromFile(file)
            }
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Respaldo Completo de Información - SYS-TF")
                putExtra(Intent.EXTRA_TEXT, "Copia de seguridad total del sistema SYS-TF (Inventario, Ventas, Finanzas, Clientes, Compras e Historial).")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "Descargar / Compartir Respaldo de Empresa").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun saveBackupToUri(context: Context, uri: Uri, jsonContent: String): Boolean {
        return try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(jsonContent.toByteArray(Charsets.UTF_8))
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun restoreCompanyBackup(
        jsonString: String,
        database: AppDatabase,
        currentUser: Employee?
    ): Result<String> {
        return try {
            val root = JSONObject(jsonString)
            if (!root.has("inventario_productos") && !root.has("ventas")) {
                return Result.failure(Exception("El archivo seleccionado no corresponde a un formato de respaldo válido de SYS-TF."))
            }
            var restoredProds = 0
            if (root.has("inventario_productos")) {
                val array = root.getJSONArray("inventario_productos")
                val localProducts = database.productDao().getAllProductsSync()
                val bySku = localProducts.filter { it.sku.isNotBlank() }.associateBy { it.sku.trim().uppercase() }
                val byName = localProducts.associateBy { it.name.trim().lowercase() }
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val rawId = obj.optString("id", "")
                    val rawSku = obj.optString("codigo", obj.optString("sku", ""))
                    val rawName = obj.optString("name", "Producto")
                    val matchedLocal = (if (rawId.isNotBlank()) localProducts.firstOrNull { it.id == rawId } else null)
                        ?: (if (rawSku.isNotBlank()) bySku[rawSku.trim().uppercase()] else null)
                        ?: byName[rawName.trim().lowercase()]
                    val prodId = matchedLocal?.id ?: (rawId.ifBlank { UUID.randomUUID().toString() })
                    val prodSku = rawSku.ifBlank { matchedLocal?.sku ?: "COD-${UUID.randomUUID().toString().take(6).uppercase()}" }
                    val prod = Product(
                        id = prodId,
                        name = rawName,
                        sku = prodSku,
                        category = obj.optString("category", matchedLocal?.category ?: "General"),
                        costPrice = obj.optDouble("costPrice", matchedLocal?.costPrice ?: 0.0),
                        salePrice = obj.optDouble("salePrice", matchedLocal?.salePrice ?: 0.0),
                        stockQuantity = obj.optInt("stockQuantity", matchedLocal?.stockQuantity ?: 0),
                        minStock = obj.optInt("minStock", matchedLocal?.minStock ?: 3),
                        imageUrl = obj.optString("imageUrl", matchedLocal?.imageUrl ?: ""),
                        description = obj.optString("description", matchedLocal?.description ?: "")
                    )
                    database.productDao().insertProduct(prod)
                    restoredProds++
                }
            }
            var restoredCustomers = 0
            if (root.has("clientes_deudores")) {
                val array = root.getJSONArray("clientes_deudores")
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val cust = Customer(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        name = obj.optString("name", "Cliente"),
                        phone = obj.optString("phone", ""),
                        email = obj.optString("email", ""),
                        address = obj.optString("address", ""),
                        currentDebt = obj.optDouble("currentDebt", 0.0),
                        creditLimit = obj.optDouble("creditLimit", 1000.0),
                        notes = obj.optString("notes", "")
                    )
                    database.customerDao().insertCustomer(cust)
                    restoredCustomers++
                }
            }
            var restoredSales = 0
            if (root.has("ventas")) {
                val array = root.getJSONArray("ventas")
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val sale = Sale(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        saleNumber = obj.optString("saleNumber", "V-${System.currentTimeMillis()}"),
                        customerId = obj.optString("customerId", "").ifBlank { null },
                        customerName = obj.optString("customerName", "Cliente Mostrador"),
                        totalAmount = obj.optDouble("totalAmount", 0.0),
                        paymentMethod = obj.optString("paymentMethod", "EFECTIVO"),
                        paymentStatus = obj.optString("paymentStatus", "PAGADO"),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        employeeId = obj.optString("employeeId", currentUser?.id ?: "alex_admin_01"),
                        employeeName = obj.optString("employeeName", currentUser?.fullName ?: "Administrador"),
                        currency = obj.optString("currency", "BOB"),
                        warehouseId = obj.optString("warehouseId", "central_wh_01"),
                        notes = obj.optString("notes", "")
                    )
                    database.saleDao().insertSale(sale)
                    restoredSales++
                }
            }
            if (root.has("items_ventas")) {
                val array = root.getJSONArray("items_ventas")
                val itemsList = mutableListOf<SaleItem>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    itemsList.add(
                        SaleItem(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            saleId = obj.optString("saleId", ""),
                            productId = obj.optString("productId", ""),
                            productName = obj.optString("productName", ""),
                            quantity = obj.optInt("quantity", 1),
                            unitPrice = obj.optDouble("unitPrice", 0.0),
                            costPrice = obj.optDouble("costPrice", 0.0),
                            subtotal = obj.optDouble("subtotal", 0.0)
                        )
                    )
                }
                if (itemsList.isNotEmpty()) {
                    database.saleDao().insertSaleItems(itemsList)
                }
            }
            var restoredExpenses = 0
            if (root.has("finanzas_gastos")) {
                val array = root.getJSONArray("finanzas_gastos")
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val exp = Expense(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        category = obj.optString("category", "Operativo"),
                        description = obj.optString("description", ""),
                        amount = obj.optDouble("amount", 0.0),
                        date = obj.optString("date", SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        employeeId = obj.optString("employeeId", currentUser?.id ?: "admin"),
                        employeeName = obj.optString("employeeName", currentUser?.fullName ?: "Administrador"),
                        isProductPurchase = obj.optBoolean("isProductPurchase", false),
                        purchaseItemsDetails = obj.optString("purchaseItemsDetails", ""),
                        receiptUrl = obj.optString("receiptUrl", "").ifBlank { null }
                    )
                    database.expenseDao().insertExpense(exp)
                    restoredExpenses++
                }
            }
            if (root.has("almacenes")) {
                val array = root.getJSONArray("almacenes")
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val wh = Warehouse(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        name = obj.optString("name", "Sucursal"),
                        location = obj.optString("location", "Central"),
                        isDefault = obj.optBoolean("isDefault", false)
                    )
                    database.warehouseDao().insertWarehouse(wh)
                }
            }
            if (root.has("configuracion_empresa")) {
                val obj = root.getJSONObject("configuracion_empresa")
                val current = database.settingsDao().getSettingsSync() ?: BusinessSettings()
                val updated = current.copy(
                    businessName = obj.optString("businessName", current.businessName),
                    taxId = obj.optString("taxId", current.taxId),
                    phone = obj.optString("phone", current.phone),
                    email = obj.optString("email", current.email),
                    address = obj.optString("address", current.address),
                    bankName = obj.optString("bankName", current.bankName),
                    bankAccount = obj.optString("bankAccount", current.bankAccount),
                    qrHolderName = obj.optString("qrHolderName", current.qrHolderName),
                    logoUrl = obj.optString("logoUrl", current.logoUrl),
                    slogan = obj.optString("slogan", current.slogan),
                    currencySymbol = obj.optString("currencySymbol", current.currencySymbol),
                    taxPercentage = obj.optDouble("taxPercentage", current.taxPercentage),
                    invoicePrefix = obj.optString("invoicePrefix", current.invoicePrefix),
                    receiptFooterMessage = obj.optString("receiptFooterMessage", current.receiptFooterMessage),
                    lowStockThreshold = obj.optInt("lowStockThreshold", current.lowStockThreshold),
                    soundAlertsEnabled = obj.optBoolean("soundAlertsEnabled", current.soundAlertsEnabled)
                )
                database.settingsDao().insertSettings(updated)
            }
            val log = AuditLog(
                dateFormatted = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date()),
                userEmail = currentUser?.email ?: "admin@sys-tf.com",
                userName = currentUser?.fullName ?: "Administrador",
                userRole = currentUser?.role ?: "ADMIN",
                actionType = "RESTAURACION_RESPALDO",
                description = "Restauración de copia de seguridad completada: $restoredProds productos, $restoredSales ventas, $restoredExpenses gastos y $restoredCustomers clientes."
            )
            database.auditLogDao().insertAuditLog(log)
            Result.success("¡Respaldo restaurado con éxito! Se cargaron $restoredProds productos, $restoredSales ventas, $restoredExpenses gastos y $restoredCustomers clientes.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
