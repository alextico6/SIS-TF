package com.example.omnigestion.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.omnigestion.data.firebase.FirestoreSyncStatus
import com.example.omnigestion.data.model.Employee
import com.example.omnigestion.data.model.RoleType
import com.example.omnigestion.data.model.Warehouse
import com.example.ui.theme.*
import coil.compose.AsyncImage

@Composable
fun MainTopBar(
    businessName: String,
    currentUser: Employee?,
    currentRole: RoleType,
    syncStatus: FirestoreSyncStatus,
    canNavigateBack: Boolean,
    logoUrl: String = "",
    activeWarehouse: Warehouse? = null,
    warehouses: List<Warehouse> = emptyList(),
    onSelectWarehouse: ((String) -> Unit)? = null,
    onAddWarehouse: ((String, String) -> Unit)? = null,
    onNavigateBack: () -> Unit,
    onProfileClick: () -> Unit
) {
    var showBranchMenu by remember { mutableStateOf(false) }
    var showNewBranchDialog by remember { mutableStateOf(false) }
    var newBranchName by remember { mutableStateOf("") }
    var newBranchLocation by remember { mutableStateOf("") }

    if (showNewBranchDialog && onAddWarehouse != null) {
        AlertDialog(
            onDismissRequest = { showNewBranchDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AddBusiness, contentDescription = null, tint = PalettePurple)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Registrar Nueva Sucursal", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Crea una nueva sucursal o sede independiente para administrar inventario, ventas y finanzas por separado.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = newBranchName,
                        onValueChange = { newBranchName = it },
                        label = { Text("Nombre (ej: Sucursal 3 - Calacoto)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newBranchLocation,
                        onValueChange = { newBranchLocation = it },
                        label = { Text("Dirección / Ubicación") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newBranchName.isNotBlank()) {
                            onAddWarehouse(newBranchName, newBranchLocation)
                            newBranchName = ""
                            newBranchLocation = ""
                            showNewBranchDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PalettePurple)
                ) {
                    Text("Crear Sucursal", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewBranchDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (canNavigateBack) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("top_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Regresar",
                            tint = PaletteCharcoal
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.size(34.dp)
                ) {
                    if (logoUrl.isNotBlank()) {
                        AsyncImage(
                            model = logoUrl,
                            contentDescription = "Logo Empresa",
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(2.dp),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Image(
                            painter = painterResource(id = R.drawable.img_app_logo),
                            contentDescription = "SYS-TF Logo",
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(2.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "SYS-TF",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = PaletteCharcoal
                    )
                    Text(
                        text = businessName.ifBlank { "OmniGestión ERP" },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = PalettePurple
                    )
                }
            }

            // Right side: Branch Selector + Profile Pill
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Branch / Sucursal Selector Pill
                if (currentRole != RoleType.CLIENTE && warehouses.isNotEmpty() && onSelectWarehouse != null) {
                    Box {
                        Surface(
                            onClick = { showBranchMenu = true },
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier
                                .height(36.dp)
                                .testTag("branch_selector_pill")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 9.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Storefront,
                                    contentDescription = null,
                                    tint = PalettePurple,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                val displayName = (activeWarehouse?.name ?: "Central").let {
                                    if (it.length > 13) it.take(11) + ".." else it
                                }
                                Text(
                                    text = displayName,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PaletteCharcoal
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showBranchMenu,
                            onDismissRequest = { showBranchMenu = false },
                            modifier = Modifier
                                .widthIn(min = 230.dp)
                                .background(Color.White)
                        ) {
                            Text(
                                text = "SUCURSALES / SEDES",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = PalettePurple,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                            warehouses.forEach { wh ->
                                val isSelected = wh.id == activeWarehouse?.id
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(
                                                text = wh.name,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                fontSize = 12.sp,
                                                color = if (isSelected) PalettePurple else PaletteCharcoal
                                            )
                                            if (wh.location.isNotBlank()) {
                                                Text(
                                                    text = wh.location,
                                                    fontSize = 10.sp,
                                                    color = Color.Gray
                                                )
                                            }
                                        }
                                    },
                                    trailingIcon = {
                                        if (isSelected) {
                                            Icon(
                                                Icons.Default.Check,
                                                contentDescription = null,
                                                tint = PalettePurple,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    },
                                    onClick = {
                                        showBranchMenu = false
                                        onSelectWarehouse(wh.id)
                                    }
                                )
                            }
                            if (currentRole == RoleType.ADMIN && onAddWarehouse != null) {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                                DropdownMenuItem(
                                    text = { Text("+ Nueva Sucursal", fontWeight = FontWeight.Bold, color = BlueAccent, fontSize = 12.sp) },
                                    leadingIcon = { Icon(Icons.Default.AddBusiness, contentDescription = null, tint = BlueAccent, modifier = Modifier.size(18.dp)) },
                                    onClick = {
                                        showBranchMenu = false
                                        showNewBranchDialog = true
                                    }
                                )
                            }
                        }
                    }
                }

                // Centralized Profile & Session Access Pill
                Surface(
                    onClick = onProfileClick,
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFFF4F5FB),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDEDFEA)),
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("central_user_profile_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(
                                    when (currentRole) {
                                        RoleType.ADMIN -> PalettePurple
                                        RoleType.EMPLEADO -> BlueAccent
                                        RoleType.CAJERO -> AmberAccent
                                        RoleType.CLIENTE -> EmeraldSuccess
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (currentUser?.fullName ?: "U").take(2).uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = currentRole.title,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PaletteCharcoal
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(if (syncStatus.isSyncing) AmberAccent else EmeraldSuccess)
                        )
                    }
                }
            }
        }
    }
}
