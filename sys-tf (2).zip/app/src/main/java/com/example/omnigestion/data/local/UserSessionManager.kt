package com.example.omnigestion.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.omnigestion.data.model.Employee
import com.example.omnigestion.data.model.RoleType

/**
 * Gestor de persistencia de sesión de usuario en SYS-TF.
 * Permite al usuario decidir si desea mantener la sesión iniciada en el dispositivo
 * o solicitar credenciales cada vez que abre la aplicación.
 */
class UserSessionManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "sys_tf_user_session_prefs"
        private const val KEY_KEEP_LOGGED_IN = "key_keep_logged_in"
        private const val KEY_USER_ID = "key_user_id"
        private const val KEY_USER_NAME = "key_user_name"
        private const val KEY_USER_EMAIL = "key_user_email"
        private const val KEY_USER_PHONE = "key_user_phone"
        private const val KEY_USER_ADDRESS = "key_user_address"
        private const val KEY_USER_ROLE = "key_user_role"
        private const val KEY_USER_PASSWORD = "key_user_password"
        private const val KEY_SAVED_IDENTIFIER = "key_saved_identifier"
        private const val KEY_INITIAL_DATA_CLEANED = "key_initial_data_cleaned_empty_v1"
    }

    var isInitialDataCleaned: Boolean
        get() = prefs.getBoolean(KEY_INITIAL_DATA_CLEANED, false)
        set(value) = prefs.edit().putBoolean(KEY_INITIAL_DATA_CLEANED, value).apply()

    /**
     * Indica si el usuario seleccionó la opción de mantener la sesión iniciada.
     * Si es true, el sistema restaurará la sesión automáticamente al iniciar la app.
     * Si es false, se solicitará usuario y contraseña al abrir la app.
     */
    var isKeepSessionLoggedIn: Boolean
        get() = prefs.getBoolean(KEY_KEEP_LOGGED_IN, true)
        set(value) = prefs.edit().putBoolean(KEY_KEEP_LOGGED_IN, value).apply()

    var savedIdentifier: String
        get() = prefs.getString(KEY_SAVED_IDENTIFIER, "") ?: ""
        set(value) = prefs.edit().putString(KEY_SAVED_IDENTIFIER, value).apply()

    /**
     * Guarda los datos de sesión del empleado autenticado.
     */
    fun saveSession(employee: Employee, keepLoggedIn: Boolean) {
        prefs.edit().apply {
            putBoolean(KEY_KEEP_LOGGED_IN, keepLoggedIn)
            putString(KEY_USER_ID, employee.id)
            putString(KEY_USER_NAME, employee.fullName)
            putString(KEY_USER_EMAIL, employee.email)
            putString(KEY_USER_PHONE, employee.phone)
            putString(KEY_USER_ADDRESS, employee.address)
            putString(KEY_USER_ROLE, employee.role)
            putString(KEY_USER_PASSWORD, employee.password)
            putString(KEY_SAVED_IDENTIFIER, employee.email.ifBlank { employee.phone })
            apply()
        }
    }

    /**
     * Recupera el empleado con sesión guardada si y solo si 'isKeepSessionLoggedIn' está activo.
     */
    fun getSavedEmployee(): Employee? {
        if (!isKeepSessionLoggedIn) return null
        val id = prefs.getString(KEY_USER_ID, null) ?: return null
        val name = prefs.getString(KEY_USER_NAME, "Usuario") ?: "Usuario"
        val email = prefs.getString(KEY_USER_EMAIL, "") ?: ""
        val phone = prefs.getString(KEY_USER_PHONE, "") ?: ""
        val address = prefs.getString(KEY_USER_ADDRESS, "") ?: ""
        val role = prefs.getString(KEY_USER_ROLE, RoleType.EMPLEADO.name) ?: RoleType.EMPLEADO.name
        val pass = prefs.getString(KEY_USER_PASSWORD, "") ?: ""
        return Employee(
            id = id,
            fullName = name,
            email = email,
            phone = phone,
            address = address,
            role = role,
            password = pass
        )
    }

    /**
     * Persistencia de borradores activos (POS, creación de productos y compras)
     * para que al salir de la aplicación no se pierda la información en curso.
     */
    fun saveCartDraft(cartMapString: String, customPricesString: String, selectedCustId: String?) {
        prefs.edit().apply {
            putString("draft_pos_cart", cartMapString)
            putString("draft_pos_custom_prices", customPricesString)
            putString("draft_pos_customer_id", selectedCustId ?: "")
            apply()
        }
    }

    fun getCartDraft(): Triple<String, String, String> {
        val cart = prefs.getString("draft_pos_cart", "") ?: ""
        val prices = prefs.getString("draft_pos_custom_prices", "") ?: ""
        val custId = prefs.getString("draft_pos_customer_id", "") ?: ""
        return Triple(cart, prices, custId)
    }

    fun clearCartDraft() {
        prefs.edit().apply {
            remove("draft_pos_cart")
            remove("draft_pos_custom_prices")
            remove("draft_pos_customer_id")
            apply()
        }
    }

    fun saveProductDraft(name: String, sku: String, category: String, cost: String, sale: String, stock: String, minStock: String, imageUrl: String, desc: String) {
        prefs.edit().apply {
            putString("draft_prod_name", name)
            putString("draft_prod_sku", sku)
            putString("draft_prod_cat", category)
            putString("draft_prod_cost", cost)
            putString("draft_prod_sale", sale)
            putString("draft_prod_stock", stock)
            putString("draft_prod_min_stock", minStock)
            putString("draft_prod_img", imageUrl)
            putString("draft_prod_desc", desc)
            apply()
        }
    }

    fun getProductDraft(): Map<String, String> {
        return mapOf(
            "name" to (prefs.getString("draft_prod_name", "") ?: ""),
            "sku" to (prefs.getString("draft_prod_sku", "") ?: ""),
            "category" to (prefs.getString("draft_prod_cat", "") ?: ""),
            "cost" to (prefs.getString("draft_prod_cost", "") ?: ""),
            "sale" to (prefs.getString("draft_prod_sale", "") ?: ""),
            "stock" to (prefs.getString("draft_prod_stock", "") ?: ""),
            "minStock" to (prefs.getString("draft_prod_min_stock", "") ?: ""),
            "imageUrl" to (prefs.getString("draft_prod_img", "") ?: ""),
            "description" to (prefs.getString("draft_prod_desc", "") ?: "")
        )
    }

    fun clearProductDraft() {
        prefs.edit().apply {
            remove("draft_prod_name")
            remove("draft_prod_sku")
            remove("draft_prod_cat")
            remove("draft_prod_cost")
            remove("draft_prod_sale")
            remove("draft_prod_stock")
            remove("draft_prod_min_stock")
            remove("draft_prod_img")
            remove("draft_prod_desc")
            apply()
        }
    }

    fun savePurchaseDraft(supplier: String, notes: String, itemsJson: String) {
        prefs.edit().apply {
            putString("draft_purch_supplier", supplier)
            putString("draft_purch_notes", notes)
            putString("draft_purch_items", itemsJson)
            apply()
        }
    }

    fun getPurchaseDraft(): Triple<String, String, String> {
        val supp = prefs.getString("draft_purch_supplier", "") ?: ""
        val notes = prefs.getString("draft_purch_notes", "") ?: ""
        val items = prefs.getString("draft_purch_items", "") ?: ""
        return Triple(supp, notes, items)
    }

    fun clearPurchaseDraft() {
        prefs.edit().apply {
            remove("draft_purch_supplier")
            remove("draft_purch_notes")
            remove("draft_purch_items")
            apply()
        }
    }

    /**
     * Cierra la sesión activa y elimina las credenciales almacenadas del dispositivo.
     */
    fun clearSession() {
        prefs.edit().apply {
            putBoolean(KEY_KEEP_LOGGED_IN, false)
            remove(KEY_USER_ID)
            remove(KEY_USER_NAME)
            remove(KEY_USER_EMAIL)
            remove(KEY_USER_PHONE)
            remove(KEY_USER_ADDRESS)
            remove(KEY_USER_ROLE)
            remove(KEY_USER_PASSWORD)
            apply()
        }
    }
}
