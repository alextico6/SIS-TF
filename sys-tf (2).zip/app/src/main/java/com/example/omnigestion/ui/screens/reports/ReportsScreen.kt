package com.example.omnigestion.ui.screens.reports

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnigestion.data.model.*
import com.example.omnigestion.data.pdf.PdfReportGenerator
import com.example.omnigestion.ui.components.omniTextFieldColors
import com.example.omnigestion.ui.viewmodel.OmniViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(viewModel: OmniViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val sales by viewModel.sales.collectAsState()
    val saleItems by viewModel.saleItems.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val products by viewModel.products.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: Financiero, 1: Rentabilidad, 2: Ventas, 3: Inventario
    var selectedPeriod by remember { mutableStateOf("MES") } // HOY, SEMANA, MES, TODO
    var searchQuery by remember { mutableStateOf("") }

    val calendar = remember { Calendar.getInstance() }
    val now = System.currentTimeMillis()

    // Filter sales and expenses by period
    val validSales = remember(sales, selectedPeriod) {
        sales.filter { sale ->
            if (sale.paymentStatus == "ANULADO") return@filter false
            when (selectedPeriod) {
                "HOY" -> {
                    calendar.timeInMillis = now
                    val y = calendar.get(Calendar.YEAR)
                    val d = calendar.get(Calendar.DAY_OF_YEAR)
                    calendar.timeInMillis = sale.timestamp
                    calendar.get(Calendar.YEAR) == y && calendar.get(Calendar.DAY_OF_YEAR) == d
                }
                "SEMANA" -> (now - sale.timestamp) <= 7 * 24 * 60 * 60 * 1000L
                "MES" -> {
                    calendar.timeInMillis = now
                    val y = calendar.get(Calendar.YEAR)
                    val m = calendar.get(Calendar.MONTH)
                    calendar.timeInMillis = sale.timestamp
                    calendar.get(Calendar.YEAR) == y && calendar.get(Calendar.MONTH) == m
                }
                else -> true
            }
        }
    }

    val validSaleIds = remember(validSales) { validSales.map { it.id }.toSet() }

    val validExpenses = remember(expenses, selectedPeriod) {
        expenses.filter { exp ->
            when (selectedPeriod) {
                "HOY" -> {
                    calendar.timeInMillis = now
                    val y = calendar.get(Calendar.YEAR)
                    val d = calendar.get(Calendar.DAY_OF_YEAR)
                    calendar.timeInMillis = exp.timestamp
                    calendar.get(Calendar.YEAR) == y && calendar.get(Calendar.DAY_OF_YEAR) == d
                }
                "SEMANA" -> (now - exp.timestamp) <= 7 * 24 * 60 * 60 * 1000L
                "MES" -> {
                    calendar.timeInMillis = now
                    val y = calendar.get(Calendar.YEAR)
                    val m = calendar.get(Calendar.MONTH)
                    calendar.timeInMillis = exp.timestamp
                    calendar.get(Calendar.YEAR) == y && calendar.get(Calendar.MONTH) == m
                }
                else -> true
            }
        }
    }

    // Financial Metrics
    val totalRevenue = remember(validSales) { validSales.sumOf { it.totalAmount } }
    val filteredSaleItems = remember(saleItems, validSaleIds) {
        saleItems.filter { validSaleIds.contains(it.saleId) }
    }
    val totalCostOfGoods = remember(filteredSaleItems) {
        filteredSaleItems.sumOf { it.costPrice * it.quantity }
    }
    val grossProfit = totalRevenue - totalCostOfGoods
    val totalOperationalExpenses = remember(validExpenses) {
        validExpenses.filter { !it.isProductPurchase }.sumOf { it.amount }
    }
    val netProfit = grossProfit - totalOperationalExpenses
    val grossMarginPercent = if (totalRevenue > 0) (grossProfit / totalRevenue) * 100 else 0.0

    // Product Profitability Stats
    val productStats = remember(filteredSaleItems, products, searchQuery) {
        val grouped = filteredSaleItems.groupBy { it.productId }
        val prodMap = products.associateBy { it.id }

        grouped.map { (pId, items) ->
            val p = prodMap[pId]
            val name = p?.name ?: items.firstOrNull()?.productName ?: "Producto Desconocido"
            val sku = p?.sku ?: ""
            val cat = p?.category ?: "General"
            val qtySold = items.sumOf { it.quantity }
            val rev = items.sumOf { it.subtotal }
            val cost = items.sumOf { it.costPrice * it.quantity }
            val profit = rev - cost
            val margin = if (rev > 0) (profit / rev) * 100 else 0.0
            val avgPrice = if (qtySold > 0) rev / qtySold else 0.0

            ProductProfitStat(
                productId = pId,
                productName = name,
                sku = sku,
                category = cat,
                imageUrl = p?.imageUrl,
                quantitySold = qtySold,
                totalRevenue = rev,
                totalCost = cost,
                totalProfit = profit,
                profitMarginPercent = margin,
                averageUnitPrice = avgPrice
            )
        }.filter { stat ->
            searchQuery.isBlank() ||
                    stat.productName.contains(searchQuery, ignoreCase = true) ||
                    stat.sku.contains(searchQuery, ignoreCase = true) ||
                    stat.category.contains(searchQuery, ignoreCase = true)
        }.sortedByDescending { it.totalProfit }
    }

    // Inventory Totals
    val totalStockUnits = remember(products) { products.sumOf { it.stockQuantity } }
    val inventoryValueAtCost = remember(products) { products.sumOf { it.costPrice * it.stockQuantity } }
    val inventoryValueAtSale = remember(products) { products.sumOf { it.salePrice * it.stockQuantity } }
    val potentialProfit = inventoryValueAtSale - inventoryValueAtCost

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Tab Selector
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Reportes y Rentabilidad", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    PrimaryTabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = { Text("Finanzas", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = { Text("Rentabilidad", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                        )
                        Tab(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            text = { Text("Ventas", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                        )
                        Tab(
                            selected = selectedTab == 3,
                            onClick = { selectedTab = 3 },
                            text = { Text("Inventario", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (selectedTab != 3) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                "HOY" to "Hoy",
                                "SEMANA" to "Semana",
                                "MES" to "Este Mes",
                                "TODO" to "Histórico"
                            ).forEach { (key, label) ->
                                FilterChip(
                                    selected = selectedPeriod == key,
                                    onClick = { selectedPeriod = key },
                                    label = { Text(label, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }
        }

        when (selectedTab) {
            0 -> {
                // Financiero Overview
                item {
                    FinancialSummaryCard(
                        totalRevenue = totalRevenue,
                        totalCost = totalCostOfGoods,
                        grossProfit = grossProfit,
                        expenses = totalOperationalExpenses,
                        netProfit = netProfit,
                        margin = grossMarginPercent,
                        currencySymbol = currency.symbol,
                        onExportPdf = {
                            val file = PdfReportGenerator.generateFinancialReportPdf(
                                context = context,
                                settings = settings,
                                sales = validSales,
                                expenses = validExpenses,
                                currency = currency
                            )
                            PdfReportGenerator.openOrSharePdf(context, file, "Reporte Financiero SYS-TF")
                        }
                    )
                }
            }

            1 -> {
                // Rentabilidad por Producto
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Ganancia Neta por Producto", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text(
                                        "${productStats.size} productos con ventas en el período",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Button(
                                    onClick = {
                                        val file = PdfReportGenerator.generateProductProfitsReportPdf(
                                            context = context,
                                            settings = settings,
                                            profitStats = productStats,
                                            periodLabel = when (selectedPeriod) {
                                                "HOY" -> "Día de Hoy"
                                                "SEMANA" -> "Últimos 7 Días"
                                                "MES" -> "Mes en Curso"
                                                else -> "Histórico Completo"
                                            },
                                            currency = currency
                                        )
                                        PdfReportGenerator.openOrSharePdf(context, file, "Rentabilidad por Producto")
                                    },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("PDF", fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                modifier = Modifier.fillMaxWidth().testTag("product_profit_search"),
                                placeholder = { Text("Filtrar por nombre o categoría...") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                shape = RoundedCornerShape(12.dp),
                                colors = omniTextFieldColors(),
                                singleLine = true
                            )
                        }
                    }
                }

                if (productStats.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                            Text("No hay ventas registradas en el período seleccionado", color = Color.Gray, fontSize = 13.sp)
                        }
                    }
                } else {
                    items(productStats, key = { it.productId }) { stat ->
                        ProductProfitItemCard(stat = stat, currencySymbol = currency.symbol)
                    }
                }
            }

            2 -> {
                // Ventas Report
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Reporte Consolidado de Ventas", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text("${validSales.size} transacciones registradas", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Button(
                                    onClick = {
                                        val file = PdfReportGenerator.generateSalesReportPdf(
                                            context = context,
                                            settings = settings,
                                            sales = validSales,
                                            currency = currency
                                        )
                                        PdfReportGenerator.openOrSharePdf(context, file, "Reporte de Ventas SYS-TF")
                                    }
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Exportar PDF", fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Breakdown by payment method
                            Text("Distribución por Método de Pago", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(8.dp))

                            PaymentMethod.entries.forEach { method ->
                                val methodSales = validSales.filter { it.paymentMethod == method.name }
                                val sum = methodSales.sumOf { it.totalAmount }
                                val count = methodSales.size
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${method.title} ($count)", fontSize = 13.sp)
                                    Text(
                                        "${currency.symbol} ${String.format(Locale.US, "%.2f", sum)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            3 -> {
                // Inventario Valuation
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Valorización de Inventario", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("${products.size} referencias • $totalStockUnits unidades totales", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                            Spacer(modifier = Modifier.height(14.dp))

                            MetricRow("Valor Total a Costo de Compra:", "${currency.symbol} ${String.format(Locale.US, "%.2f", inventoryValueAtCost)}", AmberWarning)
                            MetricRow("Valor Total a Precio de Venta:", "${currency.symbol} ${String.format(Locale.US, "%.2f", inventoryValueAtSale)}", BlueAccent)
                            MetricRow("Margen Potencial Bruto:", "${currency.symbol} ${String.format(Locale.US, "%.2f", potentialProfit)}", EmeraldSuccess)

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val file = PdfReportGenerator.generateInventoryReportPdf(
                                            context = context,
                                            settings = settings,
                                            products = products,
                                            currency = currency
                                        )
                                        PdfReportGenerator.openOrSharePdf(context, file, "Reporte de Inventario")
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("PDF Lista", fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        val file = PdfReportGenerator.generateInventoryReportPdfWithImages(
                                            context = context,
                                            settings = settings,
                                            products = products,
                                            currency = currency
                                        )
                                        PdfReportGenerator.openOrSharePdf(context, file, "Catálogo con Fotos")
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Con Fotos", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricRow(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun FinancialSummaryCard(
    totalRevenue: Double,
    totalCost: Double,
    grossProfit: Double,
    expenses: Double,
    netProfit: Double,
    margin: Double,
    currencySymbol: String,
    onExportPdf: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Resumen Financiero", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Button(onClick = onExportPdf) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Exportar PDF", fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            MetricRow("Total Ingresos (Ventas):", "$currencySymbol ${String.format(Locale.US, "%.2f", totalRevenue)}", EmeraldSuccess)
            MetricRow("Costo de Mercadería Vendida:", "$currencySymbol ${String.format(Locale.US, "%.2f", totalCost)}", AmberWarning)
            MetricRow("Utilidad Bruta:", "$currencySymbol ${String.format(Locale.US, "%.2f", grossProfit)}", BlueAccent)
            MetricRow("Gastos Operativos:", "$currencySymbol ${String.format(Locale.US, "%.2f", expenses)}", RoseDanger)

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("UTILIDAD NETA FINAL", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                    Text("Margen Bruto: ${String.format(Locale.US, "%.1f", margin)}%", fontSize = 11.sp, color = Color.Gray)
                }
                Text(
                    text = "$currencySymbol ${String.format(Locale.US, "%.2f", netProfit)}",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = if (netProfit >= 0) EmeraldSuccess else RoseDanger
                )
            }
        }
    }
}

@Composable
fun ProductProfitItemCard(stat: ProductProfitStat, currencySymbol: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(stat.productName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        "${stat.category} • SKU: ${stat.sku.ifBlank { "N/A" }}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = EmeraldSuccess.copy(alpha = 0.15f)
                ) {
                    Text(
                        "${String.format(Locale.US, "%.1f", stat.profitMarginPercent)}% margen",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldSuccess,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Unidades: ${stat.quantitySold}", fontSize = 12.sp)
                    Text("Ingresos: $currencySymbol ${String.format(Locale.US, "%.2f", stat.totalRevenue)}", fontSize = 12.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Costo: $currencySymbol ${String.format(Locale.US, "%.2f", stat.totalCost)}", fontSize = 12.sp)
                    Text(
                        "Ganancia: $currencySymbol ${String.format(Locale.US, "%.2f", stat.totalProfit)}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = EmeraldSuccess
                    )
                }
            }
        }
    }
}
