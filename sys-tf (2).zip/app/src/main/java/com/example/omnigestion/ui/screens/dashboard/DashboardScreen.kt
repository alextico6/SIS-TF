package com.example.omnigestion.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnigestion.data.model.RoleType
import com.example.omnigestion.ui.components.FirestoreSyncBadge
import com.example.omnigestion.ui.components.RechartsDashboardCard
import com.example.omnigestion.ui.components.UserSwitchDialog
import com.example.omnigestion.ui.navigation.Routes
import com.example.omnigestion.ui.viewmodel.AppScreen
import com.example.omnigestion.ui.viewmodel.OmniViewModel
import com.example.ui.theme.*
import java.util.*

@Composable
fun DashboardScreen(
    viewModel: OmniViewModel,
    onNavigate: (String) -> Unit = {}
) {
    val sales by viewModel.sales.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val products by viewModel.products.collectAsState()
    val debtorCustomers by viewModel.debtorCustomers.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()
    val employees by viewModel.employees.collectAsState()
    val firestoreSyncStatus by viewModel.firestoreSyncStatus.collectAsState()
    var showSwitchUserDialog by remember { mutableStateOf(false) }

    val totalVentas = remember(sales) { sales.filter { it.paymentStatus != "ANULADO" }.sumOf { it.totalAmount } }
    val totalGastos = remember(expenses) { expenses.sumOf { it.amount } }
    val totalDeuda = remember(debtorCustomers) { debtorCustomers.sumOf { it.currentDebt } }
    val balanceNeto = totalVentas - totalGastos

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Live Firestore Real-Time Sync Indicator
        item {
            FirestoreSyncBadge(
                syncStatus = firestoreSyncStatus,
                onSyncClick = { viewModel.triggerCloudSync() }
            )
        }

        // Welcome & User Session Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = NavyDark),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Hola, ${currentUser?.fullName ?: "Administrador"}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Rol: ${currentRole.title} • Sistema SYS-TF",
                            fontSize = 12.sp,
                            color = SlateTextMuted
                        )
                    }
                    Surface(
                        onClick = { showSwitchUserDialog = true },
                        shape = RoundedCornerShape(20.dp),
                        color = NavySurface
                    ) {
                        Text(
                            text = "Cambiar Cuenta",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Executive Balance Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Balance Financiero General", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${currency.symbol} ${String.format(Locale.US, "%,.2f", balanceNeto)}",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (balanceNeto >= 0) EmeraldSuccess else RoseDanger
                            )
                        }
                        Button(
                            onClick = {
                                onNavigate(Routes.FINANCES)
                                viewModel.navigateTo(AppScreen.FINANCES)
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text("Ver Balance", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Ingresos Ventas:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${currency.symbol} ${String.format(Locale.US, "%,.2f", totalVentas)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EmeraldSuccess)
                        }
                        Column {
                            Text("Gastos & Compras:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${currency.symbol} ${String.format(Locale.US, "%,.2f", totalGastos)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RoseDanger)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Cuentas x Cobrar:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${currency.symbol} ${String.format(Locale.US, "%,.2f", totalDeuda)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AmberAccent)
                        }
                    }
                }
            }
        }

        // Interactive Recharts Chart Component
        if (currentRole == RoleType.ADMIN) {
            item {
                RechartsDashboardCard(
                    sales = sales,
                    expenses = expenses,
                    currency = currency
                )
            }
        }

        // Quick Access Modules Grid
        item {
            Text("Módulos de Gestión SYS-TF:", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground)
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DashboardModuleCard(
                        title = "Punto de Venta",
                        subtitle = "Vender con QR o Efectivo",
                        icon = Icons.Default.PointOfSale,
                        iconTint = EmeraldSuccess,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            onNavigate(Routes.POS)
                            viewModel.navigateTo(AppScreen.POS)
                        }
                    )
                    DashboardModuleCard(
                        title = "Inventario",
                        subtitle = "Costo Total y Stock",
                        icon = Icons.Default.Warehouse,
                        iconTint = BlueAccent,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            onNavigate(Routes.INVENTORY)
                            viewModel.navigateTo(AppScreen.INVENTORY)
                        }
                    )
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DashboardModuleCard(
                        title = "Cuentas por Cobrar",
                        subtitle = "${debtorCustomers.size} clientes con saldo",
                        icon = Icons.Default.MonetizationOn,
                        iconTint = AmberAccent,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            onNavigate(Routes.DEBTORS)
                            viewModel.navigateTo(AppScreen.DEBTORS)
                        }
                    )
                    DashboardModuleCard(
                        title = "Historial Ventas",
                        subtitle = "Ver y Anular Ventas",
                        icon = Icons.Default.ReceiptLong,
                        iconTint = TealSecondary,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            onNavigate(Routes.SALES_HISTORY)
                            viewModel.navigateTo(AppScreen.SALES_HISTORY)
                        }
                    )
                }
                if (currentRole == RoleType.ADMIN) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DashboardModuleCard(
                            title = "Personal",
                            subtitle = "${employees.size} colaboradores",
                            icon = Icons.Default.People,
                            iconTint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                onNavigate(Routes.EMPLOYEES)
                                viewModel.navigateTo(AppScreen.EMPLOYEES)
                            }
                        )
                        DashboardModuleCard(
                            title = "Auditoría de Cambios",
                            subtitle = "Registro de Modificaciones",
                            icon = Icons.Default.HistoryEdu,
                            iconTint = Color(0xFF7C3AED),
                            modifier = Modifier.weight(1f),
                            onClick = {
                                onNavigate(Routes.AUDIT_LOGS)
                                viewModel.navigateTo(AppScreen.AUDIT_LOGS)
                            }
                        )
                    }
                }
            }
        }
    }

    UserSwitchDialog(
        show = showSwitchUserDialog,
        onDismiss = { showSwitchUserDialog = false },
        employees = employees,
        currentUser = currentUser,
        onSelectUser = { viewModel.quickSwitchUser(it) },
        onLogout = { viewModel.logout() }
    )
}

@Composable
private fun DashboardModuleCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}
