package com.example.omnigestion.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.omnigestion.data.model.Product
import com.example.omnigestion.data.model.PurchaseOrderItemInput
import com.example.ui.theme.*
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductPurchaseRegistrationDialog(
    initialItems: List<PurchaseOrderItemInput> = emptyList(),
    allCatalogProducts: List<Product>,
    currencySymbol: String = "Bs",
    onDismissRequest: () -> Unit,
    onConfirmPurchase: (
        supplierName: String,
        receiptVoucher: String,
        paymentMethod: String,
        notes: String,
        items: List<PurchaseOrderItemInput>,
        updateCatalogPrices: Boolean
    ) -> Unit
) {
    var supplierName by remember { mutableStateOf("Distribuidora Central") }
    var receiptVoucher by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("Efectivo") }
    var notes by remember { mutableStateOf("") }
    var updateCatalogPrices by remember { mutableStateOf(true) }

    // List of items in this purchase order
    var purchaseItems by remember { mutableStateOf(initialItems) }
    var showProductPickerModal by remember { mutableStateOf(initialItems.isEmpty()) }

    val totalPurchaseAmount = remember(purchaseItems) {
        purchaseItems.sumOf { it.quantity * it.purchasePrice }
    }
    val totalUnitsCount = remember(purchaseItems) {
        purchaseItems.sumOf { it.quantity }
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.94f)
                .testTag("product_purchase_dialog_surface"),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.background,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
            ) {
                // 1. Sticky Header
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                    shadowElevation = 2.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ShoppingBag,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Registro de Compra de Mercadería",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${purchaseItems.size} productos elegidos (${totalUnitsCount} un.)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismissRequest,
                            modifier = Modifier.testTag("close_purchase_dialog_btn")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Cerrar")
                        }
                    }
                }

                // 2. Scrollable Body containing Supplier metadata + all Product Cards
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .testTag("purchase_products_scrollable_list"),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 40.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Datos Generales de la compra
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Store,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "Datos del Proveedor y Factura",
                                        fontWeight = FontWeight.SemiBold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedTextField(
                                        value = supplierName,
                                        onValueChange = { supplierName = it },
                                        label = { Text("Proveedor") },
                                        modifier = Modifier
                                            .weight(1.2f)
                                            .testTag("purchase_supplier_input"),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = receiptVoucher,
                                        onValueChange = { receiptVoucher = it },
                                        label = { Text("Nº Factura/Recibo") },
                                        modifier = Modifier
                                            .weight(0.8f)
                                            .testTag("purchase_receipt_input"),
                                        singleLine = true
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Payment Method chips
                                    listOf("Efectivo", "Transferencia", "QR", "Crédito").forEach { method ->
                                        FilterChip(
                                            selected = paymentMethod == method,
                                            onClick = { paymentMethod = method },
                                            label = { Text(method, fontSize = 12.sp) }
                                        )
                                    }
                                }

                                OutlinedTextField(
                                    value = notes,
                                    onValueChange = { notes = it },
                                    label = { Text("Observaciones / Notas (opcional)") },
                                    modifier = Modifier.fillMaxWidth(),
                                    maxLines = 2
                                )
                            }
                        }
                    }

                    // Botón para elegir o añadir más productos del catálogo
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Lista de Productos a Comprar",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Button(
                                onClick = { showProductPickerModal = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("add_more_products_to_purchase_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Añadir Productos (+)", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }

                    // Empty state banner
                    if (purchaseItems.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.ProductionQuantityLimits,
                                        contentDescription = null,
                                        modifier = Modifier.size(48.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        text = "No has seleccionado productos aún",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyLarge
                                    )
                                    Text(
                                        text = "Toca el botón 'Añadir Productos' para buscar y seleccionar ítems del catálogo.",
                                        style = MaterialTheme.typography.bodySmall,
                                        textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(Modifier.height(14.dp))
                                    Button(
                                        onClick = { showProductPickerModal = true },
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Explorar Catálogo")
                                    }
                                }
                            }
                        }
                    }

                    // Product Cards list
                    itemsIndexed(
                        items = purchaseItems,
                        key = { _, item -> item.product.id }
                    ) { index, item ->
                        PurchaseProductItemCard(
                            index = index + 1,
                            item = item,
                            currencySymbol = currencySymbol,
                            onItemChanged = { updatedItem ->
                                val list = purchaseItems.toMutableList()
                                list[index] = updatedItem
                                purchaseItems = list
                            },
                            onRemove = {
                                val list = purchaseItems.toMutableList()
                                list.removeAt(index)
                                purchaseItems = list
                            }
                        )
                    }

                    // Scroll tip indicator
                    if (purchaseItems.size > 1) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.ArrowDownward,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = "Desliza verticalmente para revisar o modificar todos los productos",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // 3. Sticky Bottom Bar with Subtotal, Total, Catalog Update Toggle and Action Buttons
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Toggle to update catalog prices
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Switch(
                                    checked = updateCatalogPrices,
                                    onCheckedChange = { updateCatalogPrices = it },
                                    modifier = Modifier.testTag("update_catalog_prices_switch")
                                )
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Actualizar precios en inventario",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Ajusta el precio de costo y venta del producto en el catálogo",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        // Total amount summary
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "TOTAL COMPRA:",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "$currencySymbol ${String.format(Locale.US, "%,.2f", totalPurchaseAmount)}",
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedButton(
                                    onClick = onDismissRequest,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Cancelar")
                                }

                                Button(
                                    onClick = {
                                        onConfirmPurchase(
                                            supplierName,
                                            receiptVoucher,
                                            paymentMethod,
                                            notes,
                                            purchaseItems,
                                            updateCatalogPrices
                                        )
                                    },
                                    enabled = purchaseItems.isNotEmpty(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = EmeraldSuccess
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.testTag("confirm_register_purchase_btn")
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        "Registrar Compra",
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal to search and multi-select products
    if (showProductPickerModal) {
        ProductMultiPickerModal(
            allProducts = allCatalogProducts,
            selectedItemIds = purchaseItems.map { it.product.id }.toSet(),
            currencySymbol = currencySymbol,
            onDismissRequest = { showProductPickerModal = false },
            onProductsSelected = { selectedProducts ->
                // Keep existing items, append newly chosen products
                val currentMap = purchaseItems.associateBy { it.product.id }.toMutableMap()
                selectedProducts.forEach { prod ->
                    if (!currentMap.containsKey(prod.id)) {
                        currentMap[prod.id] = PurchaseOrderItemInput(
                            product = prod,
                            quantity = 1,
                            purchasePrice = prod.costPrice,
                            salePrice = prod.salePrice
                        )
                    }
                }
                purchaseItems = currentMap.values.toList()
                showProductPickerModal = false
            }
        )
    }
}

/**
 * Tarjeta de producto individual para compra de mercadería.
 *
 * Resuelve explícitamente el problema de recorte/desborde vertical:
 * - Diseño amplio, espaciado con jerarquía clara.
 * - Sección de Cantidad con stepper y accesos directos (+1, +5, +10, +25).
 * - Sección de Precios con campos independientes y accesibles.
 * - Sección de Margen de Ganancia calculada con chip de estado (% y ganancia unitaria)
 *   y botones de ajuste de margen (+20%, +30%, +40%, +50%).
 * - Sección de Subtotal destacada e inamovible.
 * - Botón de eliminación siempre accesible.
 */
@Composable
fun PurchaseProductItemCard(
    index: Int,
    item: PurchaseOrderItemInput,
    currencySymbol: String,
    onItemChanged: (PurchaseOrderItemInput) -> Unit,
    onRemove: () -> Unit
) {
    val p = item.product

    // Local text inputs for smooth user typing
    var qtyText by remember(item.quantity) { mutableStateOf(item.quantity.toString()) }
    var costText by remember(item.purchasePrice) {
        mutableStateOf(if (item.purchasePrice % 1.0 == 0.0) item.purchasePrice.toInt().toString() else item.purchasePrice.toString())
    }
    var saleText by remember(item.salePrice) {
        mutableStateOf(if (item.salePrice % 1.0 == 0.0) item.salePrice.toInt().toString() else item.salePrice.toString())
    }

    val cost = item.purchasePrice
    val sale = item.salePrice
    val qty = item.quantity
    val subtotal = qty * cost

    val profitPerUnit = sale - cost
    val marginPercent = if (cost > 0) ((profitPerUnit / cost) * 100.0) else 0.0

    val marginColor = when {
        profitPerUnit < 0 -> RoseDanger
        marginPercent < 20.0 -> AmberAccent
        else -> EmeraldSuccess
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("purchase_card_${p.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // A. Encabezado de la Tarjeta: Número, Nombre, SKU y Botón Eliminar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "#$index",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = p.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "SKU: ${p.sku}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "•",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                            Text(
                                text = "Stock actual: ${p.stockQuantity} un.",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (p.stockQuantity <= p.minStock) RoseDanger else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onRemove,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("remove_product_item_${p.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Quitar producto",
                        tint = RoseDanger
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))

            // B. Sección 1: Cantidad a comprar con stepper y accesos rápidos
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Cantidad a Ingresar",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Stepper: -
                    FilledTonalIconButton(
                        onClick = {
                            val next = (qty - 1).coerceAtLeast(1)
                            qtyText = next.toString()
                            onItemChanged(item.copy(quantity = next))
                        },
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Menos 1")
                    }

                    // Direct input field
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { input ->
                            val clean = input.filter { it.isDigit() }
                            qtyText = clean
                            val num = clean.toIntOrNull() ?: 1
                            onItemChanged(item.copy(quantity = num.coerceAtLeast(1)))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("qty_input_${p.id}"),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.titleMedium.copy(
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold
                        ),
                        trailingIcon = { Text("un.", fontSize = 12.sp, modifier = Modifier.padding(end = 8.dp)) }
                    )

                    // Stepper: +
                    FilledTonalIconButton(
                        onClick = {
                            val next = qty + 1
                            qtyText = next.toString()
                            onItemChanged(item.copy(quantity = next))
                        },
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Más 1")
                    }
                }

                // Quick Increment Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Agregar rápido:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    listOf(5, 10, 25, 50).forEach { plus ->
                        SuggestionChip(
                            onClick = {
                                val next = qty + plus
                                qtyText = next.toString()
                                onItemChanged(item.copy(quantity = next))
                            },
                            label = { Text("+$plus", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            modifier = Modifier.height(28.dp)
                        )
                    }
                }
            }

            // C. Sección 2: Precio de Compra (Costo) y Precio de Venta
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Costo
                OutlinedTextField(
                    value = costText,
                    onValueChange = { input ->
                        val clean = input.replace(',', '.')
                        if (clean.isEmpty() || clean.matches(Regex("""^\d*\.?\d*$"""))) {
                            costText = clean
                            val num = clean.toDoubleOrNull() ?: 0.0
                            onItemChanged(item.copy(purchasePrice = num))
                        }
                    },
                    label = { Text("P. Compra (Costo)") },
                    prefix = { Text("$currencySymbol ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("cost_input_${p.id}"),
                    singleLine = true
                )

                // Venta
                OutlinedTextField(
                    value = saleText,
                    onValueChange = { input ->
                        val clean = input.replace(',', '.')
                        if (clean.isEmpty() || clean.matches(Regex("""^\d*\.?\d*$"""))) {
                            saleText = clean
                            val num = clean.toDoubleOrNull() ?: 0.0
                            onItemChanged(item.copy(salePrice = num))
                        }
                    },
                    label = { Text("P. Venta Sugerido") },
                    prefix = { Text("$currencySymbol ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("sale_input_${p.id}"),
                    singleLine = true
                )
            }

            // D. Sección 3: Área del Margen de Ganancia (Con cálculo dinámico y botones de ajuste)
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, marginColor.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (profitPerUnit >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                contentDescription = null,
                                tint = marginColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = "Margen de Ganancia:",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Pill del Margen
                        Surface(
                            color = marginColor.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, marginColor)
                        ) {
                            Text(
                                text = "${String.format(Locale.US, "%+.1f", marginPercent)}%",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                                color = marginColor,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Ganancia neta por unidad:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "$currencySymbol ${String.format(Locale.US, "%.2f", profitPerUnit)} / un.",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = marginColor
                        )
                    }

                    // Chips de margen preestablecido (+20%, +30%, +40%, +50%)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Fijar margen:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        listOf(20, 30, 40, 50, 100).forEach { preset ->
                            SuggestionChip(
                                onClick = {
                                    val newSale = cost * (1.0 + preset / 100.0)
                                    val rounded = kotlin.math.round(newSale * 10.0) / 10.0
                                    saleText = if (rounded % 1.0 == 0.0) rounded.toInt().toString() else rounded.toString()
                                    onItemChanged(item.copy(salePrice = rounded))
                                },
                                label = { Text("+$preset%", fontSize = 10.sp) },
                                modifier = Modifier.height(26.dp)
                            )
                        }
                    }
                }
            }

            // E. Sección 4: Subtotal del Ítem
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Subtotal de este ítem:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "$qty un. × $currencySymbol ${String.format(Locale.US, "%.2f", cost)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(
                        text = "$currencySymbol ${String.format(Locale.US, "%,.2f", subtotal)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

/**
 * Modal para seleccionar múltiples productos del catálogo con buscador y categorías.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductMultiPickerModal(
    allProducts: List<Product>,
    selectedItemIds: Set<String>,
    currencySymbol: String,
    onDismissRequest: () -> Unit,
    onProductsSelected: (List<Product>) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Todas") }
    val currentlySelected = remember { mutableStateMapOf<String, Boolean>().apply {
        selectedItemIds.forEach { put(it, true) }
    } }

    val categories = remember(allProducts) {
        listOf("Todas") + allProducts.map { it.category }.distinct()
    }

    val filteredProducts = remember(allProducts, searchQuery, selectedCategory) {
        allProducts.filter { p ->
            val matchQuery = searchQuery.isBlank() ||
                    p.name.contains(searchQuery, ignoreCase = true) ||
                    p.sku.contains(searchQuery, ignoreCase = true)
            val matchCategory = selectedCategory == "Todas" || p.category == selectedCategory
            matchQuery && matchCategory
        }
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                "Seleccionar Productos del Catálogo",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "${currentlySelected.count { it.value }} productos seleccionados",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        IconButton(onClick = onDismissRequest) {
                            Icon(Icons.Default.Close, contentDescription = "Cerrar")
                        }
                    }
                }

                // Search & Filter
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("picker_search_input"),
                        placeholder = { Text("Buscar por nombre o SKU...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Borrar")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Categories chip row
                    ScrollableTabRow(
                        selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
                        edgePadding = 0.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        categories.forEach { cat ->
                            Tab(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                text = { Text(cat, fontSize = 12.sp) }
                            )
                        }
                    }
                }

                // Products list
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredProducts.size, key = { filteredProducts[it].id }) { i ->
                        val p = filteredProducts[i]
                        val isChecked = currentlySelected[p.id] == true

                        Card(
                            onClick = {
                                currentlySelected[p.id] = !isChecked
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isChecked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                                else MaterialTheme.colorScheme.surface
                            ),
                            border = if (isChecked) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                            else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { currentlySelected[p.id] = it }
                                )

                                Spacer(Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = p.name,
                                        fontWeight = FontWeight.SemiBold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Text(
                                        text = "SKU: ${p.sku} | Stock: ${p.stockQuantity} un.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "Costo: $currencySymbol ${p.costPrice} • Venta: $currencySymbol ${p.salePrice}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }

                // Footer
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = onDismissRequest) {
                            Text("Cancelar")
                        }

                        Button(
                            onClick = {
                                val selectedList = allProducts.filter { currentlySelected[it.id] == true }
                                onProductsSelected(selectedList)
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("confirm_product_selection_btn")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Confirmar (${currentlySelected.count { it.value }})")
                        }
                    }
                }
            }
        }
    }
}
