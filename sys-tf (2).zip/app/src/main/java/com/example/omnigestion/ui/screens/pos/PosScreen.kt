package com.example.omnigestion.ui.screens.pos

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.example.omnigestion.data.model.Customer
import com.example.omnigestion.data.model.Product
import com.example.omnigestion.data.model.Sale
import com.example.omnigestion.ui.viewmodel.CartItem
import com.example.omnigestion.ui.viewmodel.MainViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PosScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val products by viewModel.products.collectAsState()
    val cart by viewModel.cart.collectAsState()
    val selectedCustomer by viewModel.selectedCustomer.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val lastSaleReceipt by viewModel.lastSaleReceipt.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showCheckoutModal by remember { mutableStateOf(false) }
    var showCustomerPicker by remember { mutableStateOf(false) }

    val totalAmount = remember(cart) { cart.sumOf { it.subtotal } }
    val totalItemsCount = remember(cart) { cart.sumOf { it.quantity } }

    val filteredProducts = remember(products, searchQuery) {
        products.filter { p ->
            searchQuery.isBlank() ||
                    p.name.contains(searchQuery, ignoreCase = true) ||
                    p.sku.contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PointOfSale, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("Punto de Venta (POS)", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    if (cart.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearCart() }) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Vaciar Carrito", tint = RoseDanger)
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Customer Selector & Search Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Customer selection card
                Surface(
                    onClick = { showCustomerPicker = true },
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = selectedCustomer?.name ?: "Cliente Mostrador (Venta Rápida)",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp
                                )
                                if (selectedCustomer != null) {
                                    Text(
                                        text = "NIT: ${selectedCustomer!!.nit} • Deuda: ${settings.currencySymbol} ${selectedCustomer!!.currentDebt}",
                                        fontSize = 11.sp,
                                        color = if (selectedCustomer!!.currentDebt > 0) RoseDanger else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                }

                // Search field
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Buscar producto para cobrar...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = null)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // Product selection list
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 4.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredProducts, key = { it.id }) { product ->
                    val inCartItem = cart.find { it.product.id == product.id }

                    Card(
                        onClick = { viewModel.addToCart(product) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = if (inCartItem != null) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                        else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = product.name,
                                    fontWeight = FontWeight.SemiBold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${settings.currencySymbol} ${String.format(Locale.US, "%.2f", product.salePrice)}",
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "Stock: ${product.stockQuantity} un.",
                                        fontSize = 11.sp,
                                        color = if (product.stockQuantity <= product.minStock) RoseDanger else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            if (inCartItem != null) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    FilledTonalIconButton(
                                        onClick = { viewModel.updateCartQuantity(product.id, inCartItem.quantity - 1) },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                    Text(
                                        text = "${inCartItem.quantity}",
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp)
                                    )
                                    FilledTonalIconButton(
                                        onClick = { viewModel.updateCartQuantity(product.id, inCartItem.quantity + 1) },
                                        modifier = Modifier.size(34.dp),
                                        enabled = inCartItem.quantity < product.stockQuantity
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                }
                            } else {
                                Button(
                                    onClick = { viewModel.addToCart(product) },
                                    enabled = product.stockQuantity > 0,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Text("Agregar")
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Cart Bar
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Carrito ($totalItemsCount items)",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${settings.currencySymbol} ${String.format(Locale.US, "%,.2f", totalAmount)}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Button(
                        onClick = { showCheckoutModal = true },
                        enabled = cart.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("cobrar_pos_btn")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Cobrar Venta", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }
    }

    // Modal de Cobro
    if (showCheckoutModal) {
        CheckoutModal(
            totalAmount = totalAmount,
            currencySymbol = settings.currencySymbol,
            customer = selectedCustomer,
            onDismiss = { showCheckoutModal = false },
            onConfirmSale = { paymentMethod ->
                viewModel.completeSale(paymentMethod) {
                    showCheckoutModal = false
                }
            }
        )
    }

    // Modal de Recibo / Factura tras finalizar venta
    if (lastSaleReceipt != null) {
        ReceiptDialog(
            sale = lastSaleReceipt!!,
            settings = settings,
            onDismiss = { viewModel.clearLastReceipt() }
        )
    }

    // Modal para seleccionar cliente
    if (showCustomerPicker) {
        CustomerPickerModal(
            customers = customers,
            onDismiss = { showCustomerPicker = false },
            onSelect = { cust ->
                viewModel.selectCustomer(cust)
                showCustomerPicker = false
            }
        )
    }
}

@Composable
fun CheckoutModal(
    totalAmount: Double,
    currencySymbol: String,
    customer: Customer?,
    onDismiss: () -> Unit,
    onConfirmSale: (String) -> Unit
) {
    var paymentMethod by remember { mutableStateOf("Efectivo") }
    var tenderedText by remember { mutableStateOf(totalAmount.toString()) }

    val tendered = tenderedText.toDoubleOrNull() ?: 0.0
    val change = (tendered - totalAmount).coerceAtLeast(0.0)

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier.fillMaxWidth(0.92f),
        title = {
            Text("Confirmar Cobro", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Total a Pagar:", fontWeight = FontWeight.SemiBold)
                        Text(
                            "$currencySymbol ${String.format(Locale.US, "%,.2f", totalAmount)}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Text("Método de Pago:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Efectivo", "QR", "Tarjeta", "Crédito").forEach { method ->
                        FilterChip(
                            selected = paymentMethod == method,
                            onClick = { paymentMethod = method },
                            label = { Text(method, fontSize = 11.sp) }
                        )
                    }
                }

                if (paymentMethod == "Efectivo") {
                    OutlinedTextField(
                        value = tenderedText,
                        onValueChange = { tenderedText = it.replace(',', '.') },
                        label = { Text("Efectivo Recibido") },
                        prefix = { Text("$currencySymbol ") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Cambio / Vuelto:", fontWeight = FontWeight.SemiBold)
                        Text(
                            "$currencySymbol ${String.format(Locale.US, "%.2f", change)}",
                            fontWeight = FontWeight.Bold,
                            color = EmeraldSuccess
                        )
                    }
                }

                if (paymentMethod == "Crédito" && customer == null) {
                    Text(
                        "Advertencia: Selecciona un cliente registrado para habilitar venta a crédito.",
                        color = RoseDanger,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmSale(paymentMethod) },
                enabled = paymentMethod != "Crédito" || customer != null,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
            ) {
                Text("Emitir Recibo y Cobrar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

@Composable
fun ReceiptDialog(
    sale: Sale,
    settings: com.example.omnigestion.data.model.BusinessSettings,
    onDismiss: () -> Unit
) {
    val sdf = remember { SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess)
                Spacer(Modifier.width(8.dp))
                Text("Venta Exitosa")
            }
        },
        text = {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(settings.businessName, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(settings.slogan, style = MaterialTheme.typography.labelSmall)
                    Text(settings.taxId, style = MaterialTheme.typography.labelSmall)
                    Text(settings.address, style = MaterialTheme.typography.labelSmall)
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    Text("Recibo Nº: ${sale.invoiceNumber}", fontWeight = FontWeight.SemiBold)
                    Text("Fecha: ${sdf.format(Date(sale.timestamp))}", style = MaterialTheme.typography.labelSmall)
                    Text("Cliente: ${sale.customerName} (NIT: ${sale.customerNit})", style = MaterialTheme.typography.labelSmall)
                    Text("Método: ${sale.paymentMethod}", style = MaterialTheme.typography.labelSmall)
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    Text(
                        "TOTAL: ${settings.currencySymbol} ${String.format(Locale.US, "%,.2f", sale.totalAmount)}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(settings.receiptFooterMessage, textAlign = TextAlign.Center, style = MaterialTheme.typography.labelSmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Cerrar")
            }
        }
    )
}

@Composable
fun CustomerPickerModal(
    customers: List<Customer>,
    onDismiss: () -> Unit,
    onSelect: (Customer?) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Seleccionar Cliente") },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item {
                    TextButton(
                        onClick = { onSelect(null) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Cliente General (Mostrador / Sin Registro)", textAlign = TextAlign.Start, modifier = Modifier.fillMaxWidth())
                    }
                }
                items(customers) { c ->
                    Card(
                        onClick = { onSelect(c) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(c.name, fontWeight = FontWeight.SemiBold)
                            Text("NIT: ${c.nit} • Tel: ${c.phone}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
