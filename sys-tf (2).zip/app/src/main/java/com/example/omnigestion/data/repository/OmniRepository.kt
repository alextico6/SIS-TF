package com.example.omnigestion.data.repository

import androidx.room.withTransaction
import com.example.omnigestion.data.local.AppDatabase
import com.example.omnigestion.data.model.*
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

data class CsvImportResult(
    val totalProcessed: Int,
    val updatedCount: Int,
    val createdCount: Int
)

class OmniRepository(val database: AppDatabase) {
    val allProducts: Flow<List<Product>> = database.productDao().getAllProducts()
    val lowStockProducts: Flow<List<Product>> = database.productDao().getLowStockProducts()
    val allWarehouses: Flow<List<Warehouse>> = database.warehouseDao().getAllWarehouses()
    val allTransfers: Flow<List<StockTransfer>> = database.stockTransferDao().getAllTransfers()
    val allEmployees: Flow<List<Employee>> = database.employeeDao().getAllEmployees()
    val allCustomers: Flow<List<Customer>> = database.customerDao().getAllCustomers()
    val debtorCustomers: Flow<List<Customer>> = database.customerDao().getDebtorCustomers()
    val allCustomerPayments: Flow<List<CustomerPayment>> = database.customerPaymentDao().getAllPayments()
    val allSales: Flow<List<Sale>> = database.saleDao().getAllSales()
    val allSaleItems: Flow<List<SaleItem>> = database.saleDao().getAllSaleItems()
    val allExpenses: Flow<List<Expense>> = database.expenseDao().getAllExpenses()
    val allAttendances: Flow<List<Attendance>> = database.attendanceDao().getAllAttendances()
    val allAuditLogs: Flow<List<AuditLog>> = database.auditLogDao().getAllAuditLogs()
    val businessSettings: Flow<BusinessSettings?> = database.settingsDao().getSettings()
    val allPurchaseOrders: Flow<List<PurchaseOrder>> = database.purchaseOrderDao().getAllOrders()
    val allSuppliers: Flow<List<Supplier>> = database.supplierDao().getAllSuppliers()

    suspend fun ensureDefaultAdmin() {
        val employees = database.employeeDao().getAllEmployeesSync()
        // Strictly demote any other user who erroneously has ADMIN role: ONLY Alex Ticona is ADMIN
        for (emp in employees) {
            val isAlex = emp.email.equals("alexticona060@gmail.com", ignoreCase = true) ||
                    emp.email.equals("alexticona060@gmai.com", ignoreCase = true)
            if (!isAlex && emp.role == RoleType.ADMIN.name) {
                database.employeeDao().insertEmployee(emp.copy(role = RoleType.EMPLEADO.name))
            }
        }
        val exists = employees.any {
            it.email.equals("alexticona060@gmai.com", ignoreCase = true) ||
                    it.email.equals("alexticona060@gmail.com", ignoreCase = true)
        }
        if (!exists) {
            val alexAdmin = Employee(
                id = "emp_alex_admin",
                fullName = "Alex Ticona (Administrador General)",
                email = "alexticona060@gmail.com",
                phone = "70001717",
                address = "Oficina Principal SYS-TF",
                role = RoleType.ADMIN.name,
                password = "1717",
                baseSalary = 5000.0,
                commissionRate = 0.0
            )
            database.employeeDao().insertEmployee(alexAdmin)
        }
        val currentWarehouses = database.warehouseDao().getAllWarehousesSync()
        if (currentWarehouses.isEmpty()) {
            database.warehouseDao().insertWarehouses(listOf(
                Warehouse(id = "wh_central", name = "Casa Matriz - Central", location = "Av. Principal #500", isDefault = true),
                Warehouse(id = "wh_sucursal1", name = "Sucursal 1 - Norte", location = "Calle 14 de Septiembre #220", isDefault = false),
                Warehouse(id = "wh_sucursal2", name = "Sucursal 2 - Sur", location = "Av. Circunvalación #1050", isDefault = false)
            ))
        } else if (currentWarehouses.none { it.id == "wh_sucursal2" }) {
            database.warehouseDao().insertWarehouse(
                Warehouse(id = "wh_sucursal2", name = "Sucursal 2 - Sur", location = "Av. Circunvalación #1050", isDefault = false)
            )
        }
    }

    suspend fun insertWarehouse(warehouse: Warehouse) = database.warehouseDao().insertWarehouse(warehouse)

    suspend fun getProductById(id: String): Product? = database.productDao().getProductById(id)

    suspend fun insertProduct(product: Product, user: Employee? = null) {
        val existing = database.productDao().getProductById(product.id)
        database.productDao().insertProduct(product)
        logAudit(
            user = user,
            action = if (existing == null) AuditActionType.PRODUCTO_CREADO else AuditActionType.PRODUCTO_EDITADO,
            entityId = product.id,
            description = "Producto '${product.name}' (Código: ${product.sku}) guardado. Stock: ${product.stockQuantity}, Precio: Bs ${product.salePrice}",
            prev = existing?.let { "Stock: ${it.stockQuantity}, Precio: Bs ${it.salePrice}" } ?: "",
            curr = "Stock: ${product.stockQuantity}, Precio: Bs ${product.salePrice}"
        )
    }

    suspend fun deleteProduct(product: Product, user: Employee? = null) {
        database.productDao().deleteProduct(product)
        logAudit(
            user = user,
            action = AuditActionType.PRODUCTO_ELIMINADO,
            entityId = product.id,
            description = "Producto eliminado: ${product.name} (Código: ${product.sku})",
            prev = "Stock: ${product.stockQuantity}, Costo: Bs ${product.costPrice}",
            curr = "Eliminado"
        )
    }

    suspend fun deleteProductsByIds(ids: List<String>, user: Employee? = null) {
        database.productDao().deleteProductsByIds(ids)
        logAudit(
            user = user,
            action = AuditActionType.PRODUCTO_ELIMINADO,
            entityId = ids.joinToString(","),
            description = "Eliminación masiva de ${ids.size} productos del catálogo",
            prev = "${ids.size} productos",
            curr = "Eliminados"
        )
    }

    suspend fun deleteAllProducts(user: Employee? = null): Int {
        val count = database.productDao().deleteAllProducts()
        logAudit(
            user = user,
            action = AuditActionType.PRODUCTO_ELIMINADO,
            entityId = "ALL_PRODUCTS",
            description = "Vaciado completo de inventario: $count productos eliminados desde cero",
            prev = "$count productos",
            curr = "0 productos (Inventario vacío)"
        )
        return count
    }

    suspend fun restoreDefaultCatalog(user: Employee? = null): Int {
        val defaultItems = com.example.omnigestion.data.local.CatalogDataSeed.getInitialCatalog()
        database.productDao().insertProducts(defaultItems)
        logAudit(
            user = user,
            action = AuditActionType.PRODUCTO_CREADO,
            entityId = "DEFAULT_CATALOG",
            description = "Restauración de catálogo inicial: ${defaultItems.size} productos cargados",
            prev = "Catálogo previo",
            curr = "${defaultItems.size} productos"
        )
        return defaultItems.size
    }

    suspend fun recountStock(productId: String, countedQuantity: Int, user: Employee? = null) {
        val prod = database.productDao().getProductById(productId) ?: return
        val prevStock = prod.stockQuantity
        database.productDao().updateStock(productId, countedQuantity)
        logAudit(
            user = user,
            action = AuditActionType.AJUSTE_STOCK,
            entityId = productId,
            description = "Conteo Físico para '${prod.name}'. Diferencia: ${countedQuantity - prevStock} unidades",
            prev = "$prevStock unidades",
            curr = "$countedQuantity unidades"
        )
    }

    // Branch Stock Transfer
    suspend fun executeTransfer(
        transfer: StockTransfer,
        items: List<StockTransferItem>,
        user: Employee? = null
    ) {
        database.stockTransferDao().insertTransfer(transfer)
        database.stockTransferDao().insertTransferItems(items)
        for (item in items) {
            database.productDao().addStock(item.productId, -item.quantity)
        }
        logAudit(
            user = user,
            action = AuditActionType.TRASPASO,
            entityId = transfer.id,
            description = "Traspaso Nº ${transfer.transferNumber} de '${transfer.sourceWarehouseName}' a '${transfer.targetWarehouseName}'. Total: ${transfer.totalUnits} unidades",
            prev = "En origen",
            curr = "Traspasado a destino"
        )
    }

    suspend fun getTransferItems(transferId: String): List<StockTransferItem> {
        return database.stockTransferDao().getItemsForTransfer(transferId)
    }

    // Process Sale
    suspend fun processSale(sale: Sale, items: List<SaleItem>, user: Employee? = null) {
        database.saleDao().insertSale(sale)
        database.saleDao().insertSaleItems(items)
        for (item in items) {
            database.productDao().addStock(item.productId, -item.quantity)
        }
        if (sale.paymentMethod == PaymentMethod.CREDITO.name && sale.customerId != null) {
            database.customerDao().increaseDebt(sale.customerId, sale.totalAmount)
        }
        logAudit(
            user = user,
            action = AuditActionType.VENTA,
            entityId = sale.id,
            description = "Venta ${sale.saleNumber} por Bs ${String.format(Locale.US, "%.2f", sale.totalAmount)} a ${sale.customerName} (${sale.paymentMethod})",
            prev = "Stock previo",
            curr = "Vendido"
        )
    }

    suspend fun voidSale(saleId: String, user: Employee? = null) {
        val items = database.saleDao().getSaleItems(saleId)
        val sales = database.saleDao().getAllSalesSync()
        val sale = sales.firstOrNull { it.id == saleId }
        database.saleDao().voidSale(saleId)
        for (item in items) {
            database.productDao().addStock(item.productId, item.quantity)
        }
        if (sale?.paymentMethod == PaymentMethod.CREDITO.name && sale.customerId != null) {
            database.customerDao().reduceDebt(sale.customerId, sale.totalAmount)
        }
        logAudit(
            user = user,
            action = AuditActionType.ANULACION_VENTA,
            entityId = saleId,
            description = "Venta ${sale?.saleNumber ?: saleId} anulada. Stock devuelto al almacén.",
            prev = "Venta activa Bs ${sale?.totalAmount ?: 0.0}",
            curr = "Venta anulada (stock revertido)"
        )
    }

    suspend fun deleteSalePermanent(saleId: String, user: Employee? = null) {
        val items = database.saleDao().getSaleItems(saleId)
        val sales = database.saleDao().getAllSalesSync()
        val sale = sales.firstOrNull { it.id == saleId }
        if (sale != null && !sale.paymentStatus.startsWith("ANULA", ignoreCase = true)) {
            for (item in items) {
                database.productDao().addStock(item.productId, item.quantity)
            }
            if (sale.paymentMethod == PaymentMethod.CREDITO.name && sale.customerId != null) {
                database.customerDao().reduceDebt(sale.customerId, sale.totalAmount)
            }
        }
        database.saleDao().deleteSaleItemsBySaleId(saleId)
        database.saleDao().deleteSaleById(saleId)
        logAudit(
            user = user,
            action = AuditActionType.ANULACION_VENTA,
            entityId = saleId,
            description = "Venta ${sale?.saleNumber ?: saleId} eliminada permanentemente del sistema.",
            prev = "Venta registrada (${sale?.paymentStatus})",
            curr = "Registro eliminado"
        )
    }

    suspend fun getSaleItems(saleId: String): List<SaleItem> {
        return database.saleDao().getSaleItems(saleId)
    }

    suspend fun getAllSaleItemsSync(): List<SaleItem> {
        return database.saleDao().getAllSaleItemsSync()
    }

    suspend fun updateSale(
        updatedSale: Sale,
        updatedItems: List<SaleItem>,
        user: Employee? = null
    ) {
        val oldItems = database.saleDao().getSaleItems(updatedSale.id)
        val oldSales = database.saleDao().getAllSalesSync()
        val oldSale = oldSales.firstOrNull { it.id == updatedSale.id }

        // 1. Adjust inventory stock differences
        val oldMap = oldItems.groupBy { it.productId }.mapValues { it.value.sumOf { item -> item.quantity } }
        val newMap = updatedItems.groupBy { it.productId }.mapValues { it.value.sumOf { item -> item.quantity } }
        val allProdIds = (oldMap.keys + newMap.keys).distinct()
        for (prodId in allProdIds) {
            val oldQty = oldMap[prodId] ?: 0
            val newQty = newMap[prodId] ?: 0
            val diff = newQty - oldQty
            if (diff != 0) {
                database.productDao().addStock(prodId, -diff)
            }
        }

        // 2. Adjust customer debt if this was/is a credit sale
        if (oldSale != null) {
            val wasCredit = oldSale.paymentMethod == PaymentMethod.CREDITO.name && oldSale.customerId != null
            val isCredit = updatedSale.paymentMethod == PaymentMethod.CREDITO.name && updatedSale.customerId != null
            if (wasCredit && isCredit) {
                if (oldSale.customerId == updatedSale.customerId) {
                    val debtDiff = updatedSale.totalAmount - oldSale.totalAmount
                    if (debtDiff > 0) {
                        database.customerDao().increaseDebt(oldSale.customerId!!, debtDiff)
                    } else if (debtDiff < 0) {
                        database.customerDao().reduceDebt(oldSale.customerId!!, -debtDiff)
                    }
                } else {
                    database.customerDao().reduceDebt(oldSale.customerId!!, oldSale.totalAmount)
                    database.customerDao().increaseDebt(updatedSale.customerId!!, updatedSale.totalAmount)
                }
            } else if (wasCredit && !isCredit) {
                database.customerDao().reduceDebt(oldSale.customerId!!, oldSale.totalAmount)
            } else if (!wasCredit && isCredit) {
                database.customerDao().increaseDebt(updatedSale.customerId!!, updatedSale.totalAmount)
            }
        }

        // 3. Persist updated sale and refreshed sale items
        database.saleDao().updateSale(updatedSale)
        database.saleDao().deleteSaleItemsBySaleId(updatedSale.id)
        database.saleDao().insertSaleItems(updatedItems)

        // 4. Audit Trail
        logAudit(
            user = user,
            action = AuditActionType.CORRECCION_VENTA,
            entityId = updatedSale.id,
            description = "Venta ${updatedSale.saleNumber} modificada. Cliente: ${updatedSale.customerName}, Total: Bs ${String.format(Locale.US, "%.2f", updatedSale.totalAmount)}",
            prev = "Cliente: ${oldSale?.customerName}, Bs ${String.format(Locale.US, "%.2f", oldSale?.totalAmount ?: 0.0)}",
            curr = "Cliente: ${updatedSale.customerName}, Bs ${String.format(Locale.US, "%.2f", updatedSale.totalAmount)}"
        )
    }

    // Customer Management (CRM)
    suspend fun saveCustomer(customer: Customer, user: Employee? = null) {
        val existing = database.customerDao().getCustomerById(customer.id)
        database.customerDao().insertCustomer(customer)
        logAudit(
            user = user,
            action = if (existing == null) AuditActionType.PRODUCTO_CREADO else AuditActionType.PRODUCTO_EDITADO,
            entityId = customer.id,
            description = if (existing == null) "Nuevo cliente registrado: ${customer.name} (Tel: ${customer.phone})" else "Datos de cliente actualizados: ${customer.name}",
            prev = existing?.name ?: "",
            curr = customer.name
        )
    }

    suspend fun deleteCustomer(customer: Customer, user: Employee? = null): Boolean {
        if (customer.currentDebt > 0.01) {
            return false
        }
        database.customerDao().deleteCustomer(customer)
        logAudit(
            user = user,
            action = AuditActionType.PRODUCTO_ELIMINADO,
            entityId = customer.id,
            description = "Cliente eliminado: ${customer.name}",
            prev = customer.name,
            curr = "Eliminado"
        )
        return true
    }

    suspend fun updateExpense(expense: Expense, user: Employee? = null) {
        database.expenseDao().updateExpense(expense)
        logAudit(
            user = user,
            action = AuditActionType.CORRECCION_GASTO,
            entityId = expense.id,
            description = "Gasto modificado: ${expense.category} - Bs ${String.format(Locale.US, "%.2f", expense.amount)}",
            prev = "",
            curr = "Bs ${String.format(Locale.US, "%.2f", expense.amount)}"
        )
    }

    suspend fun receiveProductPurchase(
        product: Product,
        incomingQuantity: Int,
        newCostPrice: Double,
        updateMethod: CostUpdateMethod,
        lotDescription: String = "",
        user: Employee? = null
    ) {
        val oldStock = product.stockQuantity
        val oldCost = product.costPrice
        val finalCost = when (updateMethod) {
            CostUpdateMethod.DIRECT_UPDATE -> newCostPrice
            CostUpdateMethod.WEIGHTED_AVERAGE -> {
                val totalUnits = oldStock + incomingQuantity
                if (totalUnits > 0) {
                    ((oldStock * oldCost) + (incomingQuantity * newCostPrice)) / totalUnits
                } else newCostPrice
            }
            CostUpdateMethod.KEEP_PREVIOUS -> oldCost
        }
        val updatedProduct = product.copy(
            stockQuantity = oldStock + incomingQuantity,
            costPrice = finalCost
        )
        database.productDao().updateProduct(updatedProduct)
        val totalExpense = incomingQuantity * newCostPrice
        val expense = Expense(
            category = ExpenseCategory.COMPRAS_PRODUCTOS.title,
            description = "Compra de productos: ${incomingQuantity}x ${product.name} (Costo: Bs ${String.format(Locale.US, "%.2f", newCostPrice)})${if (lotDescription.isNotBlank()) " - Lote: $lotDescription" else ""}",
            amount = totalExpense,
            date = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()),
            employeeId = user?.id ?: "emp_admin",
            employeeName = user?.fullName ?: "Administrador",
            isProductPurchase = true,
            purchaseItemsDetails = "${incomingQuantity}x ${product.name} @ Bs ${String.format(Locale.US, "%.2f", newCostPrice)}"
        )
        database.expenseDao().insertExpense(expense)
        logAudit(
            user = user,
            action = AuditActionType.COMPRA_MERCADERIA,
            entityId = product.id,
            description = "Compra de ${incomingQuantity} unid. de '${product.name}'. Costo ant: Bs ${String.format(Locale.US, "%.2f", oldCost)} -> Nuevo: Bs ${String.format(Locale.US, "%.2f", finalCost)}",
            prev = "Stock: $oldStock, Costo: $oldCost",
            curr = "Stock: ${oldStock + incomingQuantity}, Costo: $finalCost"
        )
    }

    suspend fun adjustProductStock(
        productId: String,
        delta: Int,
        reason: String,
        user: Employee? = null
    ) {
        val prod = database.productDao().getProductById(productId) ?: return
        val oldStock = prod.stockQuantity
        val newStock = (oldStock + delta).coerceAtLeast(0)
        database.productDao().updateStock(productId, newStock)
        logAudit(
            user = user,
            action = AuditActionType.AJUSTE_STOCK,
            entityId = productId,
            description = "Ajuste manual de inventario en '${prod.name}': ${if (delta >= 0) "+$delta" else "$delta"} unid. (Motivo: $reason)",
            prev = "Stock: $oldStock",
            curr = "Stock: $newStock"
        )
    }

    suspend fun recordCustomerPayment(
        customer: Customer,
        amount: Double,
        paymentMethod: String,
        employee: Employee?,
        notes: String = ""
    ) {
        val payment = CustomerPayment(
            customerId = customer.id,
            customerName = customer.name,
            amount = amount,
            dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date()),
            recordedByEmployeeId = employee?.id ?: "",
            recordedByEmployeeName = employee?.fullName ?: "Cajero",
            paymentMethod = paymentMethod,
            notes = notes
        )
        database.customerPaymentDao().insertPayment(payment)
        database.customerDao().reduceDebt(customer.id, amount)
        logAudit(
            user = employee,
            action = AuditActionType.PAGO_DEUDA,
            entityId = customer.id,
            description = "Abono de deuda: ${customer.name} pagó Bs ${String.format(Locale.US, "%.2f", amount)} vía $paymentMethod",
            prev = "Deuda previa: Bs ${customer.currentDebt}",
            curr = "Nueva deuda: Bs ${Math.max(0.0, customer.currentDebt - amount)}"
        )
    }

    suspend fun getCustomerById(id: String): Customer? = database.customerDao().getCustomerById(id)

    suspend fun clearCustomerDebt(customerId: String, user: Employee? = null) {
        val customer = database.customerDao().getCustomerById(customerId) ?: return
        val prevDebt = customer.currentDebt
        database.customerDao().clearDebt(customerId)
        logAudit(
            user = user,
            action = AuditActionType.CORRECCION_VENTA,
            entityId = customerId,
            description = "Deuda de Bs ${String.format(Locale.US, "%.2f", prevDebt)} eliminada / condonada por Administrador para el cliente '${customer.name}'.",
            prev = "Deuda previa: Bs ${String.format(Locale.US, "%.2f", prevDebt)}",
            curr = "Deuda actual: Bs 0.00"
        )
    }

    suspend fun insertExpense(
        expense: Expense,
        purchasedProducts: List<Pair<Product, Int>> = emptyList(),
        user: Employee? = null
    ) {
        database.expenseDao().insertExpense(expense)
        for ((prod, qty) in purchasedProducts) {
            database.productDao().addStock(prod.id, qty)
        }
        val isPurchase = expense.isProductPurchase
        logAudit(
            user = user,
            action = if (isPurchase) AuditActionType.COMPRA_MERCADERIA else AuditActionType.GASTO,
            entityId = expense.id,
            description = "Gasto registrado: ${expense.description} por Bs ${String.format(Locale.US, "%.2f", expense.amount)}.",
            prev = "",
            curr = "Bs ${expense.amount}"
        )
    }

    suspend fun deleteExpense(expense: Expense, user: Employee? = null) {
        database.expenseDao().deleteExpense(expense)
        logAudit(
            user = user,
            action = AuditActionType.CORRECCION_GASTO,
            entityId = expense.id,
            description = "Gasto eliminado: ${expense.description} (Bs ${expense.amount})",
            prev = "Bs ${expense.amount}",
            curr = "Eliminado"
        )
    }

    suspend fun insertEmployee(employee: Employee, user: Employee? = null) {
        database.employeeDao().insertEmployee(employee)
        logAudit(
            user = user,
            action = AuditActionType.PRODUCTO_CREADO,
            entityId = employee.id,
            description = "Colaborador guardado: ${employee.fullName} (Rol: ${employee.role})",
            prev = "",
            curr = "Activo"
        )
    }

    suspend fun deleteEmployee(employee: Employee, user: Employee? = null) {
        database.employeeDao().deleteEmployee(employee)
        logAudit(
            user = user,
            action = AuditActionType.EMPLEADO_ELIMINADO,
            entityId = employee.id,
            description = "Colaborador eliminado: ${employee.fullName} (${employee.role})",
            prev = employee.email,
            curr = "Eliminado"
        )
    }

    suspend fun clockIn(employee: Employee, notes: String = ""): Attendance {
        val now = System.currentTimeMillis()
        val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(now))
        val att = Attendance(
            employeeId = employee.id,
            employeeName = employee.fullName,
            checkInTime = now,
            dateStr = dateStr,
            notes = notes
        )
        database.attendanceDao().insertAttendance(att)
        logAudit(
            user = employee,
            action = AuditActionType.PRODUCTO_EDITADO,
            entityId = employee.id,
            description = "Marcado de ENTRADA por ${employee.fullName} a las ${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now))}",
            prev = "Fuera de servicio",
            curr = "En turno"
        )
        return att
    }

    suspend fun clockOut(employee: Employee, notes: String = ""): Attendance? {
        val active = database.attendanceDao().getActiveShift(employee.id) ?: return null
        val now = System.currentTimeMillis()
        val hours = ((now - active.checkInTime) / (1000.0 * 60 * 60)).let { Math.round(it * 10.0) / 10.0 }
        val updated = active.copy(checkOutTime = now, hoursWorked = hours, notes = if (notes.isNotBlank()) notes else active.notes)
        database.attendanceDao().updateAttendance(updated)
        logAudit(
            user = employee,
            action = AuditActionType.PRODUCTO_EDITADO,
            entityId = employee.id,
            description = "Marcado de SALIDA por ${employee.fullName}. Total horas: $hours hrs",
            prev = "En turno",
            curr = "Turno cerrado"
        )
        return updated
    }

    suspend fun updateSettings(settings: BusinessSettings, user: Employee? = null) {
        database.settingsDao().insertSettings(settings)
        logAudit(
            user = user,
            action = AuditActionType.PRODUCTO_EDITADO,
            entityId = settings.id,
            description = "Ajustes de empresa actualizados: ${settings.businessName}, ${settings.taxId}, ${settings.phone}",
            prev = "",
            curr = "Actualizado"
        )
    }

    suspend fun deduplicateCatalog(user: Employee? = null): Int {
        val all = database.productDao().getAllProductsSync()
        if (all.size <= 1) return 0
        val idsToDelete = mutableListOf<String>()
        val seenSkus = mutableSetOf<String>()
        val seenNames = mutableSetOf<String>()
        for (p in all) {
            val skuKey = p.sku.trim().uppercase()
            val nameKey = p.name.trim().lowercase()
            var isDuplicate = false
            if (skuKey.isNotBlank()) {
                if (seenSkus.contains(skuKey)) {
                    isDuplicate = true
                } else {
                    seenSkus.add(skuKey)
                }
            }
            if (nameKey.isNotBlank()) {
                if (seenNames.contains(nameKey)) {
                    isDuplicate = true
                } else {
                    seenNames.add(nameKey)
                }
            }
            if (isDuplicate) {
                idsToDelete.add(p.id)
            }
        }
        if (idsToDelete.isNotEmpty()) {
            database.productDao().deleteProductsByIds(idsToDelete)
            logAudit(
                user = user,
                action = AuditActionType.PRODUCTO_ELIMINADO,
                entityId = "DEDUPLICATE",
                description = "Depuración de catálogo: ${idsToDelete.size} productos duplicados eliminados",
                prev = "${all.size} productos",
                curr = "${all.size - idsToDelete.size} productos únicos"
            )
        }
        return idsToDelete.size
    }

    suspend fun importCsvProducts(csvText: String, replaceAll: Boolean = true, user: Employee? = null): CsvImportResult {
        val trimmed = csvText.trim().trimStart('\uFEFF')
        if (trimmed.isBlank()) return CsvImportResult(0, 0, 0)

        val isHtmlTable = trimmed.contains("<table", ignoreCase = true) || trimmed.contains("<tr", ignoreCase = true)
        val parsedRows = mutableListOf<List<String>>()

        if (isHtmlTable) {
            val trRegex = Regex("<tr[^>]*>(.*?)</tr>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
            val cellRegex = Regex("<t[dh][^>]*>(.*?)</t[dh]>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
            val tagStripRegex = Regex("<[^>]*>")
            for (trMatch in trRegex.findAll(trimmed)) {
                val rowHtml = trMatch.groupValues[1]
                val cells = cellRegex.findAll(rowHtml).map {
                    val raw = it.groupValues[1]
                    tagStripRegex.replace(raw, "")
                        .replace("&nbsp;", " ")
                        .replace("&amp;", "&")
                        .replace("&lt;", "<")
                        .replace("&gt;", ">")
                        .replace("&quot;", "\"")
                        .trim()
                }.toList()
                if (cells.isNotEmpty() && cells.any { it.isNotBlank() }) {
                    parsedRows.add(cells)
                }
            }
        } else {
            val firstLineCandidate = trimmed.lines().firstOrNull { it.isNotBlank() } ?: ""
            val delimiter = when {
                firstLineCandidate.count { it == ';' } > firstLineCandidate.count { it == ',' } -> ';'
                firstLineCandidate.count { it == '\t' } > firstLineCandidate.count { it == ',' } -> '\t'
                firstLineCandidate.count { it == '|' } > firstLineCandidate.count { it == ',' } -> '|'
                else -> ','
            }

            val currentRow = mutableListOf<String>()
            val currentCell = StringBuilder()
            var inQuotes = false
            var i = 0
            val len = trimmed.length

            while (i < len) {
                val c = trimmed[i]
                if (c == '\"') {
                    if (inQuotes && i + 1 < len && trimmed[i + 1] == '\"') {
                        currentCell.append('\"')
                        i++
                    } else {
                        inQuotes = !inQuotes
                    }
                } else if (c == delimiter && !inQuotes) {
                    currentRow.add(currentCell.toString().trim())
                    currentCell.setLength(0)
                } else if ((c == '\n' || c == '\r') && !inQuotes) {
                    if (c == '\r' && i + 1 < len && trimmed[i + 1] == '\n') {
                        i++
                    }
                    currentRow.add(currentCell.toString().trim())
                    currentCell.setLength(0)
                    if (currentRow.any { it.isNotBlank() }) {
                        parsedRows.add(currentRow.toList())
                    }
                    currentRow.clear()
                } else {
                    currentCell.append(c)
                }
                i++
            }
            if (currentCell.isNotEmpty() || currentRow.isNotEmpty()) {
                currentRow.add(currentCell.toString().trim())
                if (currentRow.any { it.isNotBlank() }) {
                    parsedRows.add(currentRow.toList())
                }
            }
        }

        if (parsedRows.isEmpty()) return CsvImportResult(0, 0, 0)

        fun parseDoubleClean(str: String?): Double? {
            if (str.isNullOrBlank()) return null
            val s = str.trim()
                .replace("Bs.", "", ignoreCase = true)
                .replace("Bs", "", ignoreCase = true)
                .replace("BOB", "", ignoreCase = true)
                .replace("USD", "", ignoreCase = true)
                .replace("$", "")
                .replace(" ", "")
                .replace("c/u", "", ignoreCase = true)
                .replace(".-", "")
                .trim()
                .replace(" ", "")
            if (s.isEmpty()) return null
            val hasComma = s.contains(",")
            val hasDot = s.contains(".")
            val standardized = if (hasComma && hasDot) {
                if (s.lastIndexOf(",") > s.lastIndexOf(".")) {
                    s.replace(".", "").replace(",", ".")
                } else {
                    s.replace(",", "")
                }
            } else if (hasComma) {
                s.replace(",", ".")
            } else {
                s
            }
            val filtered = standardized.filter { it.isDigit() || it == '.' || it == '-' }
            return filtered.toDoubleOrNull()
        }

        fun parseIntClean(str: String?): Int? {
            val d = parseDoubleClean(str) ?: return null
            return d.roundToInt()
        }

        var headerRowIdx = -1
        for (i in 0 until minOf(parsedRows.size, 10)) {
            val r = parsedRows[i].map { it.lowercase() }
            if (r.any {
                    it.contains("nombre") || it.contains("name") || it.contains("producto") ||
                    it.contains("sku") || it.contains("codigo") || it.contains("código") ||
                    it.contains("articulo") || it.contains("artículo") || it.contains("precio") ||
                    it.contains("costo") || it.contains("stock") || it.contains("cant")
                }) {
                headerRowIdx = i
                break
            }
        }

        var colId = -1
        var colIndexNum = -1
        var colName = -1
        var colSku = -1
        var colCat = -1
        var colCost = -1
        var colSale = -1
        var colStock = -1
        var colMin = -1
        var colDesc = -1
        var colImage = -1

        if (headerRowIdx != -1) {
            val headerCols = parsedRows[headerRowIdx]
            headerCols.forEachIndexed { idx, rawH ->
                val h = rawH.trim().lowercase()
                    .replace("_", " ")
                    .replace("-", " ")
                    .replace(".", "")
                    .replace("(", "")
                    .replace(")", "")
                    .trim()
                when {
                    h == "nº" || h == "nro" || h == "no" || h == "num" || h == "numero" || h == "#" || h == "item #" || h == "n" -> {
                        colIndexNum = idx
                    }
                    h == "id" || h == "id producto" || h == "identificador" || h == "product id" || h == "uuid" -> {
                        colId = idx
                    }
                    h.contains("min") || h.contains("alerta") || h.contains("minimo") || h.contains("mínimo") -> {
                        colMin = idx
                    }
                    h.contains("estado") || h.contains("status") || h.contains("margen") || h.contains("margin") || h.contains("utilidad") -> {
                    }
                    h.contains("stock") || h.contains("cant") || h.contains("existencia") || h.contains("unidades") || h.contains("qty") || h.contains("saldo") || h.contains("inventario") -> {
                        if (colStock == -1) colStock = idx
                    }
                    h.contains("cost") || h.contains("compra") || h.contains("adquisicion") || h.contains("adquisición") || h == "pcosto" || h == "pcompra" -> {
                        colCost = idx
                    }
                    h.contains("venta") || h.contains("pvp") || h.contains("precio venta") || h.contains("pventa") || h.contains("sale") || h.contains("unitario") -> {
                        colSale = idx
                    }
                    (h.contains("precio") || h.contains("price") || h.contains("importe") || h.contains("valor")) && colSale == -1 && colCost != idx -> {
                        colSale = idx
                    }
                    h.contains("sku") || h.contains("codigo") || h.contains("código") || h == "cod" || h == "cód" || h.contains("barcode") || h.contains("barra") || h.contains("referencia") || h == "ref" || h == "clave" -> {
                        colSku = idx
                    }
                    h.contains("cat") || h.contains("rubro") || h.contains("familia") || h.contains("tipo") || h.contains("linea") || h.contains("línea") || h.contains("grupo") || h.contains("seccion") || h.contains("sección") -> {
                        colCat = idx
                    }
                    h.contains("imagen") || h.contains("image") || h.contains("foto") -> {
                        colImage = idx
                    }
                    h.contains("descrip") || h.contains("detalle") || h.contains("nota") || h.contains("observac") -> {
                        colDesc = idx
                    }
                    (h.contains("nombre") || h.contains("name") || h.contains("articulo") || h.contains("artículo") || h.contains("producto") || h == "item" || h.contains("concepto") || h.contains("titulo") || h.contains("título") || h.contains("denominacion") || h.contains("denominación")) && !h.contains("id") && !h.contains("codigo") && !h.contains("código") -> {
                        colName = idx
                    }
                }
            }
            if (colName == -1 && colDesc != -1) {
                colName = colDesc
                colDesc = -1
            }
        } else {
            colName = 0
            if (parsedRows.first().size > 1) colSku = 1
            if (parsedRows.first().size > 2) colCat = 2
            if (parsedRows.first().size > 3) colCost = 3
            if (parsedRows.first().size > 4) colSale = 4
            if (parsedRows.first().size > 5) colStock = 5
            if (parsedRows.first().size > 6) colMin = 6
            if (parsedRows.first().size > 7) colDesc = 7
        }

        if (colName == -1) {
            colName = if (colIndexNum == 0 && parsedRows.first().size > 1) 1 else 0
        }

        val startIndex = if (headerRowIdx != -1) headerRowIdx + 1 else 0
        val existingProducts = if (replaceAll) emptyList() else database.productDao().getAllProductsSync()
        val byId = existingProducts.associateBy { it.id }.toMutableMap()
        val bySku = existingProducts.filter { it.sku.isNotBlank() }.associateBy { it.sku.trim().uppercase() }.toMutableMap()
        val byName = existingProducts.associateBy { it.name.trim().lowercase() }.toMutableMap()
        val finalProductsMap = LinkedHashMap<String, Product>()
        val seenSkusInBatch = mutableMapOf<String, String>()
        val seenNamesInBatch = mutableMapOf<String, String>()
        var updatedCount = 0
        var createdCount = 0

        for (i in startIndex until parsedRows.size) {
            val cols = parsedRows[i]
            if (cols.isEmpty() || cols.all { it.isBlank() }) continue
            val rawName = if (colName in cols.indices) cols[colName].trim() else ""
            if (rawName.isBlank()) continue
            val rawSku = if (colSku in cols.indices) cols[colSku].trim() else ""
            val rawCat = if (colCat in cols.indices) cols[colCat].trim() else ""
            val rawCostStr = if (colCost in cols.indices) cols[colCost] else null
            val rawSaleStr = if (colSale in cols.indices) cols[colSale] else null
            val rawStockStr = if (colStock in cols.indices) cols[colStock] else null
            val rawMinStr = if (colMin in cols.indices) cols[colMin] else null
            val rawDesc = if (colDesc in cols.indices) cols[colDesc].trim() else ""
            val rawImage = if (colImage in cols.indices) cols[colImage].trim() else ""
            val rawId = if (colId in cols.indices) cols[colId].trim() else ""

            val normSku = rawSku.uppercase()
            val normName = rawName.lowercase()

            val batchIdMatch = (if (normSku.isNotBlank()) seenSkusInBatch[normSku] else null) ?: seenNamesInBatch[normName]
            val batchProduct = if (batchIdMatch != null) finalProductsMap[batchIdMatch] else null
            val existing = batchProduct ?: (if (rawId.isNotBlank()) byId[rawId] else null)
                ?: (if (normSku.isNotBlank()) bySku[normSku] else null)
                ?: byName[normName]

            val parsedCost = parseDoubleClean(rawCostStr)
            val parsedSale = parseDoubleClean(rawSaleStr)

            val cost: Double
            val sale: Double
            if (parsedSale != null && parsedCost != null) {
                sale = parsedSale
                cost = parsedCost
            } else if (parsedSale != null) {
                sale = parsedSale
                cost = existing?.costPrice ?: 0.0
            } else if (parsedCost != null) {
                cost = parsedCost
                sale = existing?.salePrice ?: cost
            } else {
                sale = existing?.salePrice ?: 0.0
                cost = existing?.costPrice ?: 0.0
            }

            val stock = parseIntClean(rawStockStr) ?: (existing?.stockQuantity ?: 0)
            val minStock = parseIntClean(rawMinStr) ?: (existing?.minStock ?: 3)
            val sku = if (rawSku.isNotBlank()) rawSku else (existing?.sku ?: "")
            val cat = if (rawCat.isNotBlank()) rawCat else (existing?.category ?: "General")
            val desc = if (rawDesc.isNotBlank()) rawDesc else (existing?.description ?: "")
            val img = if (rawImage.isNotBlank()) rawImage else (existing?.imageUrl ?: "")

            if (existing != null) {
                val updatedProduct = existing.copy(
                    name = rawName,
                    sku = sku,
                    category = cat,
                    costPrice = cost,
                    salePrice = sale,
                    stockQuantity = stock,
                    minStock = minStock,
                    description = desc,
                    imageUrl = img
                )
                finalProductsMap[existing.id] = updatedProduct
                byId[existing.id] = updatedProduct
                if (normSku.isNotBlank()) {
                    bySku[normSku] = updatedProduct
                    seenSkusInBatch[normSku] = existing.id
                }
                byName[normName] = updatedProduct
                seenNamesInBatch[normName] = existing.id
                updatedCount++
            } else {
                val newId = if (rawId.isNotBlank() && !byId.containsKey(rawId)) rawId else UUID.randomUUID().toString()
                val newProduct = Product(
                    id = newId,
                    name = rawName,
                    sku = sku,
                    category = cat,
                    costPrice = cost,
                    salePrice = sale,
                    stockQuantity = stock,
                    minStock = minStock,
                    description = desc,
                    imageUrl = img,
                    warehouseId = "wh_central"
                )
                finalProductsMap[newId] = newProduct
                byId[newId] = newProduct
                if (normSku.isNotBlank()) {
                    bySku[normSku] = newProduct
                    seenSkusInBatch[normSku] = newId
                }
                byName[normName] = newProduct
                seenNamesInBatch[normName] = newId
                createdCount++
            }
        }

        if (finalProductsMap.isNotEmpty()) {
            if (replaceAll) {
                database.productDao().deleteAllProducts()
            }
            database.productDao().insertProducts(finalProductsMap.values.toList())
            logAudit(
                user = user,
                action = AuditActionType.PRODUCTO_CREADO,
                entityId = "csv_import",
                description = if (replaceAll) "Catálogo reemplazado completamente desde archivo: ${finalProductsMap.size} productos cargados tal como están"
                else "Importación CSV/Excel: $updatedCount actualizados, $createdCount nuevos agregados sin duplicar",
                prev = if (replaceAll) "Catálogo anterior vaciado" else "",
                curr = "${finalProductsMap.size} productos en catálogo"
            )
        }
        return CsvImportResult(
            totalProcessed = finalProductsMap.size,
            updatedCount = updatedCount,
            createdCount = createdCount
        )
    }

    suspend fun createPurchaseOrder(
        order: PurchaseOrder,
        items: List<PurchaseOrderItem>,
        user: Employee? = null
    ) {
        database.purchaseOrderDao().insertOrder(order)
        database.purchaseOrderDao().insertOrderItems(items)
        logAudit(
            user = user,
            action = AuditActionType.COMPRA_MERCADERIA,
            entityId = order.id,
            description = "Pedido #${order.orderNumber} a proveedor '${order.supplierName}' por Bs ${String.format(Locale.US, "%.2f", order.estimatedTotalCost)}",
            prev = "Sin pedido",
            curr = "Pedido PENDIENTE registrado"
        )
    }

    suspend fun receivePurchaseOrder(
        orderId: String,
        user: Employee? = null,
        registerExpense: Boolean = true
    ) {
        val order = database.purchaseOrderDao().getOrderById(orderId) ?: return
        val items = database.purchaseOrderDao().getOrderItems(orderId)
        database.purchaseOrderDao().updateOrderStatus(orderId, "RECIBIDO")
        val detailParts = mutableListOf<String>()
        for (item in items) {
            val prod = database.productDao().getProductById(item.productId)
            if (prod != null) {
                val oldStock = prod.stockQuantity
                val newUnits = item.quantity
                val oldCost = prod.costPrice
                val newCost = item.estimatedUnitCost
                val totalUnits = oldStock + newUnits
                val finalCost = if (totalUnits > 0 && newCost > 0) {
                    ((oldStock * oldCost) + (newUnits * newCost)) / totalUnits
                } else if (newCost > 0) newCost else oldCost
                database.productDao().updateProduct(
                    prod.copy(
                        stockQuantity = oldStock + newUnits,
                        costPrice = finalCost
                    )
                )
            } else {
                database.productDao().addStock(item.productId, item.quantity)
            }
            detailParts.add("${item.quantity}x ${item.productName}")
        }
        if (registerExpense && order.estimatedTotalCost > 0) {
            val expense = Expense(
                category = ExpenseCategory.COMPRAS_PRODUCTOS.title,
                description = "Compra / Recepción de Pedido #${order.orderNumber} (${order.supplierName})",
                amount = order.estimatedTotalCost,
                date = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()),
                employeeId = user?.id ?: "emp_admin",
                employeeName = user?.fullName ?: "Administrador",
                isProductPurchase = true,
                purchaseItemsDetails = detailParts.joinToString("; ")
            )
            database.expenseDao().insertExpense(expense)
        }
        logAudit(
            user = user,
            action = AuditActionType.COMPRA_MERCADERIA,
            entityId = orderId,
            description = "Pedido #${order.orderNumber} RECIBIDO. ${items.sumOf { it.quantity }} unidades ingresadas al stock",
            prev = "Estado: PENDIENTE",
            curr = "Estado: RECIBIDO (Stock actualizado)"
        )
    }

    suspend fun getPurchaseOrderItems(orderId: String): List<PurchaseOrderItem> {
        return database.purchaseOrderDao().getOrderItems(orderId)
    }

    suspend fun deletePurchaseOrder(order: PurchaseOrder, user: Employee? = null) {
        database.purchaseOrderDao().deleteOrder(order)
        logAudit(
            user = user,
            action = AuditActionType.PRODUCTO_ELIMINADO,
            entityId = order.id,
            description = "Pedido #${order.orderNumber} a ${order.supplierName} cancelado",
            prev = "Pedido ${order.orderNumber}",
            curr = "Cancelado"
        )
    }

    suspend fun addStock(productId: String, quantity: Int, user: Employee? = null) {
        database.productDao().addStock(productId, quantity)
        val prod = database.productDao().getProductById(productId)
        logAudit(
            user = user,
            action = AuditActionType.AJUSTE_STOCK,
            entityId = productId,
            description = "Ingreso de stock: +$quantity unidades a '${prod?.name ?: productId}'",
            prev = "${(prod?.stockQuantity ?: 0) - quantity}",
            curr = "${prod?.stockQuantity ?: 0}"
        )
    }

    suspend fun modifyProductPurchase(
        expenseId: String?,
        productId: String?,
        newQuantity: Int,
        newPurchasePrice: Double,
        newSalePrice: Double,
        newSupplier: String,
        newTimestamp: Long? = null,
        user: Employee? = null
    ) {
        if (!productId.isNullOrBlank()) {
            val prod = database.productDao().getProductById(productId)
            if (prod != null) {
                val updatedProd = prod.copy(
                    costPrice = if (newPurchasePrice > 0) newPurchasePrice else prod.costPrice,
                    salePrice = if (newSalePrice > 0) newSalePrice else prod.salePrice
                )
                database.productDao().updateProduct(updatedProd)
            }
        }
        if (!expenseId.isNullOrBlank()) {
            val expenses = database.expenseDao().getAllExpensesSync()
            val existingExpense = expenses.firstOrNull { it.id == expenseId }
            if (existingExpense != null) {
                val newTotalAmount = if (newQuantity > 0 && newPurchasePrice > 0) newQuantity * newPurchasePrice else existingExpense.amount
                val updatedDesc = if (newSupplier.isNotBlank()) {
                    if (existingExpense.description.contains("productos (") || existingExpense.description.contains("Compra de ")) {
                        existingExpense.description
                    } else {
                        "Compra a $newSupplier: $newQuantity un. a Bs $newPurchasePrice (Venta: Bs $newSalePrice)"
                    }
                } else existingExpense.description
                val updatedDetails = if (newSupplier.isNotBlank() && !existingExpense.purchaseItemsDetails.contains(" | ")) {
                    "Proveedor: $newSupplier | Cant: $newQuantity | Costo: $newPurchasePrice | Venta: $newSalePrice"
                } else if (newSupplier.isNotBlank() && existingExpense.purchaseItemsDetails.contains("Proveedor: ")) {
                    existingExpense.purchaseItemsDetails.replace(Regex("Proveedor: [^|]+"), "Proveedor: $newSupplier")
                } else existingExpense.purchaseItemsDetails
                val updated = existingExpense.copy(
                    description = updatedDesc,
                    amount = if (newTotalAmount > 0) newTotalAmount else existingExpense.amount,
                    purchaseItemsDetails = updatedDetails,
                    timestamp = newTimestamp ?: existingExpense.timestamp,
                    date = if (newTimestamp != null) SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(newTimestamp)) else existingExpense.date
                )
                database.expenseDao().updateExpense(updated)
            }
        }
        logAudit(
            user = user,
            action = AuditActionType.COMPRA_MERCADERIA,
            entityId = expenseId ?: productId ?: "PURCHASE",
            description = "Compra modificada: Proveedor '$newSupplier', Cant: $newQuantity, Costo: $newPurchasePrice, Venta: $newSalePrice",
            prev = "Compra previa",
            curr = "Proveedor: $newSupplier, Cant: $newQuantity, Costo: $newPurchasePrice, Venta: $newSalePrice"
        )
    }

    suspend fun saveSupplier(supplier: Supplier, user: Employee? = null) {
        database.supplierDao().insertSupplier(supplier)
        logAudit(
            user = user,
            action = AuditActionType.PROVEEDOR_CREADO,
            entityId = supplier.id,
            description = "Proveedor guardado: ${supplier.name} (${supplier.phone})",
            prev = "",
            curr = supplier.name
        )
    }

    suspend fun deleteSupplier(supplier: Supplier, user: Employee? = null) {
        database.supplierDao().deleteSupplier(supplier)
        logAudit(
            user = user,
            action = AuditActionType.PROVEEDOR_ELIMINADO,
            entityId = supplier.id,
            description = "Proveedor eliminado: ${supplier.name}",
            prev = supplier.name,
            curr = "Eliminado"
        )
    }

    suspend fun wipeAllBusinessData(keyword: String, user: Employee?): Boolean {
        if (keyword.trim() != "ticox") return false
        database.withTransaction {
            database.productDao().deleteAllProducts()
            database.saleDao().deleteAllSales()
            database.saleDao().deleteAllSaleItems()
            database.expenseDao().deleteAllExpenses()
            database.purchaseOrderDao().deleteAllOrders()
            database.purchaseOrderDao().deleteAllOrderItems()
            database.stockTransferDao().deleteAllTransfers()
            database.stockTransferDao().deleteAllTransferItems()
            database.customerPaymentDao().deleteAllPayments()
            database.customerDao().clearAllCustomerDebts()
            database.customerDao().deleteAllCustomers()
            database.auditLogDao().deleteAllAuditLogs()
            val log = AuditLog(
                dateFormatted = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date()),
                userEmail = user?.email ?: "alexticona060@gmail.com",
                userName = user?.fullName ?: "Administrador",
                userRole = RoleType.ADMIN.name,
                actionType = "REINICIO_TOTAL",
                entityId = "ALL",
                description = "Vaciado total del sistema autorizado con clave 'ticox'",
                previousValue = "Base de datos completa",
                newValue = "Limpio"
            )
            database.auditLogDao().insertAuditLog(log)
        }
        return true
    }

    suspend fun clearAllInitialData() {
        database.withTransaction {
            database.productDao().deleteAllProducts()
            database.customerDao().deleteAllCustomers()
            database.customerPaymentDao().deleteAllPayments()
            database.saleDao().deleteAllSales()
            database.saleDao().deleteAllSaleItems()
            database.purchaseOrderDao().deleteAllOrders()
            database.purchaseOrderDao().deleteAllOrderItems()
            database.expenseDao().deleteAllExpenses()
            database.stockTransferDao().deleteAllTransfers()
            database.stockTransferDao().deleteAllTransferItems()
        }
    }

    private suspend fun logAudit(
        user: Employee?,
        action: AuditActionType,
        entityId: String,
        description: String,
        prev: String = "",
        curr: String = ""
    ) {
        val log = AuditLog(
            dateFormatted = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date()),
            userEmail = user?.email ?: "admin@sys-tf.com",
            userName = user?.fullName ?: "Sistema / Admin",
            userRole = user?.role ?: RoleType.ADMIN.name,
            actionType = action.title,
            entityId = entityId,
            description = description,
            previousValue = prev,
            newValue = curr
        )
        database.auditLogDao().insertAuditLog(log)
    }
}
