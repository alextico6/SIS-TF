package com.example.omnigestion.data.local

import com.example.omnigestion.data.model.*
import java.util.UUID

object CatalogDataSeed {
    suspend fun seedInitialData(database: AppDatabase) {
        val productDao = database.productDao()
        val existingProducts = productDao.getAllProductsSync()
        if (existingProducts.isEmpty()) {
            val initialProducts = listOf(
                Product(
                    id = "PROD-001",
                    name = "Taladro Percutor Bosch 650W GSB 13 RE",
                    sku = "HERR-TAL-001",
                    category = "Herramientas Eléctricas",
                    costPrice = 380.0,
                    salePrice = 495.0,
                    stockQuantity = 12,
                    minStock = 5,
                    imageUrl = null
                ),
                Product(
                    id = "PROD-002",
                    name = "Amoladora Angular DeWalt 800W 4 1/2\"",
                    sku = "HERR-AMO-002",
                    category = "Herramientas Eléctricas",
                    costPrice = 420.0,
                    salePrice = 560.0,
                    stockQuantity = 8,
                    minStock = 4,
                    imageUrl = null
                ),
                Product(
                    id = "PROD-003",
                    name = "Juego Destornilladores Stanley 6 Piezas",
                    sku = "HERR-MAN-003",
                    category = "Herramientas Manuales",
                    costPrice = 45.0,
                    salePrice = 75.0,
                    stockQuantity = 25,
                    minStock = 8,
                    imageUrl = null
                ),
                Product(
                    id = "PROD-004",
                    name = "Disco de Corte Extra Fino Norton 4 1/2\" (Caja x25)",
                    sku = "CONS-DIS-004",
                    category = "Consumibles y Abrasivos",
                    costPrice = 85.0,
                    salePrice = 135.0,
                    stockQuantity = 40,
                    minStock = 10,
                    imageUrl = null
                ),
                Product(
                    id = "PROD-005",
                    name = "Cable UTP Cat6 100% Cobre Exterior 305m",
                    sku = "RED-CAB-005",
                    category = "Redes y Conectividad",
                    costPrice = 520.0,
                    salePrice = 710.0,
                    stockQuantity = 6,
                    minStock = 3,
                    imageUrl = null
                ),
                Product(
                    id = "PROD-006",
                    name = "Router Gigabit WiFi 6 Dual Band Archer AX12",
                    sku = "RED-ROU-006",
                    category = "Redes y Conectividad",
                    costPrice = 240.0,
                    salePrice = 345.0,
                    stockQuantity = 15,
                    minStock = 5,
                    imageUrl = null
                ),
                Product(
                    id = "PROD-007",
                    name = "Cerradura Biométrica Digital Inteligente WiFi",
                    sku = "SEG-CER-007",
                    category = "Seguridad Electrónica",
                    costPrice = 680.0,
                    salePrice = 950.0,
                    stockQuantity = 4,
                    minStock = 2,
                    imageUrl = null
                ),
                Product(
                    id = "PROD-008",
                    name = "Cámara de Seguridad Exterior 4MP WiFi Solar",
                    sku = "SEG-CAM-008",
                    category = "Seguridad Electrónica",
                    costPrice = 310.0,
                    salePrice = 460.0,
                    stockQuantity = 9,
                    minStock = 4,
                    imageUrl = null
                ),
                Product(
                    id = "PROD-009",
                    name = "Foco Reflector Solar LED 100W con Panel y Control",
                    sku = "ILUM-SOL-009",
                    category = "Iluminación",
                    costPrice = 110.0,
                    salePrice = 175.0,
                    stockQuantity = 18,
                    minStock = 6,
                    imageUrl = null
                ),
                Product(
                    id = "PROD-010",
                    name = "Cinta Aislante 3M Scotch 20m Negra",
                    sku = "ELEC-CIN-010",
                    category = "Electricidad",
                    costPrice = 6.5,
                    salePrice = 12.0,
                    stockQuantity = 60,
                    minStock = 20,
                    imageUrl = null
                )
            )
            productDao.insertProducts(initialProducts)
        }

        val settingsDao = database.settingsDao()
        if (settingsDao.getSettingsSync() == null) {
            settingsDao.saveSettings(
                BusinessSettings(
                    id = "default_settings",
                    businessName = "SYS-TF",
                    taxId = "NIT: 102938475",
                    phone = "+591 70011223",
                    email = "ventas@sys-tf.bo",
                    address = "Av. Principal #123, Zona Central",
                    slogan = "Ferretería & Tecnología Integral",
                    logoUrl = null,
                    currencySymbol = "Bs",
                    taxPercentage = 13.0,
                    invoicePrefix = "FAC-",
                    receiptFooterMessage = "¡Gracias por su compra en SYS-TF! Garantía de calidad.",
                    bankAccount = "1000-2938-4829",
                    bankName = "Banco Unión",
                    qrHolderName = "Alex Ticona Flores"
                )
            )
        }

        val employeeDao = database.employeeDao()
        if (employeeDao.getAllEmployeesSync().isEmpty()) {
            employeeDao.insertEmployee(
                Employee(
                    id = "EMP-001",
                    name = "Alex Ticona Flores",
                    role = RoleType.ADMIN.name,
                    email = "alex.ticona@sys-tf.bo",
                    pin = "1234",
                    phone = "+591 70011223"
                )
            )
            employeeDao.insertEmployee(
                Employee(
                    id = "EMP-002",
                    name = "Marcos Mendoza",
                    role = RoleType.CAJERO.name,
                    email = "caja1@sys-tf.bo",
                    pin = "1111",
                    phone = "+591 72345678"
                )
            )
        }

        val customerDao = database.customerDao()
        if (customerDao.getAllCustomersSync().isEmpty()) {
            customerDao.insertCustomer(
                Customer(
                    id = "CUST-001",
                    name = "Constructora El Roble S.R.L.",
                    phone = "+591 71239845",
                    nit = "3847291012",
                    address = "Calacoto Calle 15 #450",
                    creditLimit = 15000.0,
                    currentDebt = 3200.0
                )
            )
            customerDao.insertCustomer(
                Customer(
                    id = "CUST-002",
                    name = "Ing. Roberto Quiroga",
                    phone = "+591 68901234",
                    nit = "4920193021",
                    address = "Av. Arce Edif. Illimani",
                    creditLimit = 5000.0,
                    currentDebt = 850.0
                )
            )
            customerDao.insertCustomer(
                Customer(
                    id = "CUST-003",
                    name = "Cliente Casual / Mostrador",
                    phone = "0",
                    nit = "0",
                    address = "Venta Directa",
                    creditLimit = 0.0,
                    currentDebt = 0.0
                )
            )
        }

        val expenseDao = database.expenseDao()
        if (expenseDao.getAllExpensesSync().isEmpty()) {
            expenseDao.insertExpense(
                Expense(
                    id = UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis() - 86400000L * 3,
                    amount = 450.0,
                    category = ExpenseCategory.GASTOS_LOGISTICOS.name,
                    description = "Flete transporte de herramientas desde aduana",
                    supplierName = "Transportes Bolivia Express",
                    receiptVoucher = "REC-8921",
                    paymentMethod = "Efectivo",
                    isProductPurchase = false
                )
            )
            expenseDao.insertExpense(
                Expense(
                    id = UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis() - 86400000L * 1,
                    amount = 1200.0,
                    category = ExpenseCategory.COMPRAS_PRODUCTOS.name,
                    description = "Compra de reposición stock herramientas manuales",
                    supplierName = "Distribuidora Industrial Bosch & Stanley",
                    receiptVoucher = "FAC-4412",
                    paymentMethod = "Transferencia",
                    isProductPurchase = true,
                    purchaseItemsDetails = "10x Taladro Percutor, 15x Juego Destornilladores"
                )
            )
        }
    }
}
