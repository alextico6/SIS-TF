package com.example.omnigestion.data.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.omnigestion.data.model.Product
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object InventoryFileExporter {
    private const val TAG = "InventoryFileExporter"

    /**
     * Builds standard CSV text with UTF-8 BOM so Excel opens Spanish characters cleanly.
     */
    fun generateCsvContent(products: List<Product>): String {
        val sb = StringBuilder()
        sb.append("Nombre,Codigo,Categoria,Precio_Costo,Precio_Venta,Margen_Porcentaje,Stock_Actual,Stock_Minimo,Estado_Stock,Descripcion\n")
        for (p in products) {
            val marginPct = if (p.salePrice > 0) ((p.salePrice - p.costPrice) / p.salePrice) * 100.0 else 0.0
            val status = when {
                p.stockQuantity <= 0 -> "AGOTADO"
                p.stockQuantity <= p.minStock -> "STOCK_BAJO"
                else -> "DISPONIBLE"
            }
            val row = listOf(
                escapeCsv(p.name),
                escapeCsv(p.sku),
                escapeCsv(p.category),
                String.format(Locale.US, "%.2f", p.costPrice),
                String.format(Locale.US, "%.2f", p.salePrice),
                String.format(Locale.US, "%.1f", marginPct),
                p.stockQuantity.toString(),
                p.minStock.toString(),
                status,
                escapeCsv(p.description)
            ).joinToString(",")
            sb.append(row).append("\n")
        }
        return sb.toString()
    }

    /**
     * Exports products to standard CSV with UTF-8 BOM and saves to cache + Downloads.
     */
    fun exportToCsv(context: Context, products: List<Product>, currencySymbol: String): File {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "Inventario_SYS_TF_$timestamp.csv"
        val file = File(context.cacheDir, fileName)
        FileOutputStream(file).use { fos ->
            fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
            val writer = fos.bufferedWriter(Charsets.UTF_8)
            writer.write(generateCsvContent(products))
            writer.flush()
        }
        saveToDownloads(context, file, "text/csv")
        return file
    }

    /**
     * Builds Excel-compatible HTML/XML Spreadsheet (.xls)
     */
    fun generateExcelHtmlContent(products: List<Product>, currencySymbol: String): String {
        val totalCost = products.sumOf { it.costPrice * it.stockQuantity }
        val totalValuation = products.sumOf { it.salePrice * it.stockQuantity }
        val totalUnits = products.sumOf { it.stockQuantity }
        val sb = StringBuilder()
        sb.append(
            """
            <!DOCTYPE html>
            <html>
            <head>
            <meta charset="utf-8">
            <style>
                body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #FAFAFD; margin: 15px; color: #21222D; }
                h2 { color: #21222D; margin-bottom: 4px; }
                .subtitle { color: #555566; font-size: 13px; margin-bottom: 12px; }
                .stats-box { background-color: #21222D; color: #FFFFFF; padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; }
                .stats-val { font-size: 18px; font-weight: bold; color: #ACD1FD; }
                table { border-collapse: collapse; width: 100%; font-size: 12px; background: #FFFFFF; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
                th { background-color: #21222D; color: #FFFFFF; font-weight: bold; padding: 10px 8px; border: 1px solid #14151C; text-align: left; }
                td { padding: 8px; border: 1px solid #E2E4EB; }
                tr:nth-child(even) { background-color: #F8F9FE; }
                .number { text-align: right; }
                .sku { font-family: monospace; font-weight: bold; color: #4B4682; }
                .ok { color: #059669; font-weight: bold; }
                .low { color: #D97706; font-weight: bold; }
                .out { color: #DC2626; font-weight: bold; }
            </style>
            </head>
            <body>
            <h2>SYS-TF • Reporte de Inventario y Existencias</h2>
            <p class="subtitle">Generado el: ${SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())} | Total Productos: ${products.size}</p>
            <div class="stats-box">
                Valor Total Inventario: <span class="stats-val">$currencySymbol ${String.format(Locale.US, "%,.2f", totalValuation)}</span> &nbsp;|&nbsp;
                Costo Total: <span class="stats-val">$currencySymbol ${String.format(Locale.US, "%,.2f", totalCost)}</span> &nbsp;|&nbsp;
                Unidades Totales: <span class="stats-val">$totalUnits</span>
            </div>
            <table>
            <thead>
                <tr>
                    <th style="width: 35px;">Nº</th>
                    <th>Nombre del Producto</th>
                    <th>Código</th>
                    <th>Categoría</th>
                    <th style="text-align: right;">Costo ($currencySymbol)</th>
                    <th style="text-align: right;">Precio Venta ($currencySymbol)</th>
                    <th style="text-align: right;">Margen (%)</th>
                    <th style="text-align: right;">Stock Actual</th>
                    <th style="text-align: right;">Mínimo</th>
                    <th>Estado</th>
                    <th>Descripción</th>
                </tr>
            </thead>
            <tbody>
            """.trimIndent()
        )
        sb.append("\n")
        products.forEachIndexed { index, p ->
            val marginPct = if (p.salePrice > 0) ((p.salePrice - p.costPrice) / p.salePrice) * 100.0 else 0.0
            val (statusText, statusClass) = when {
                p.stockQuantity <= 0 -> Pair("Agotado", "out")
                p.stockQuantity <= p.minStock -> Pair("Stock Bajo", "low")
                else -> Pair("Disponible", "ok")
            }
            sb.append(
                """
                <tr>
                    <td>${index + 1}</td>
                    <td><b>${escapeHtml(p.name)}</b></td>
                    <td class="sku">${escapeHtml(p.sku)}</td>
                    <td>${escapeHtml(p.category)}</td>
                    <td class="number">${String.format(Locale.US, "%.2f", p.costPrice)}</td>
                    <td class="number"><b>${String.format(Locale.US, "%.2f", p.salePrice)}</b></td>
                    <td class="number">${String.format(Locale.US, "%.1f", marginPct)}%</td>
                    <td class="number ${statusClass}">${p.stockQuantity}</td>
                    <td class="number">${p.minStock}</td>
                    <td class="${statusClass}">${statusText}</td>
                    <td>${escapeHtml(p.description)}</td>
                </tr>
                """.trimIndent()
            ).append("\n")
        }
        sb.append(
            """
            </tbody>
            </table>
            </body>
            </html>
            """.trimIndent()
        )
        return sb.toString()
    }

    fun exportToExcelXml(context: Context, products: List<Product>, currencySymbol: String): File {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "Inventario_SYS_TF_$timestamp.xls"
        val file = File(context.cacheDir, fileName)
        FileOutputStream(file).use { fos ->
            val writer = fos.bufferedWriter(Charsets.UTF_8)
            writer.write(generateExcelHtmlContent(products, currencySymbol))
            writer.flush()
        }
        saveToDownloads(context, file, "application/vnd.ms-excel")
        return file
    }

    fun writeContentToUri(context: Context, targetUri: Uri, content: String, isUtf8Bom: Boolean = false): Boolean {
        return try {
            context.contentResolver.openOutputStream(targetUri)?.use { out ->
                if (isUtf8Bom) {
                    out.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                }
                out.write(content.toByteArray(Charsets.UTF_8))
                out.flush()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error writing to URI: ${e.message}", e)
            false
        }
    }

    fun saveToDownloads(context: Context, sourceFile: File, mimeType: String): Uri? {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                var values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, sourceFile.name)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SYS-TF")
                }
                var uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri == null) {
                    values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, sourceFile.name)
                        put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                }
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        sourceFile.inputStream().use { input ->
                            input.copyTo(out)
                        }
                    }
                    return uri
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val target = File(downloadsDir, sourceFile.name)
                sourceFile.copyTo(target, overwrite = true)
                return Uri.fromFile(target)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not copy directly to public Downloads: ${e.message}")
        }
        return null
    }

    fun openOrShareFile(context: Context, file: File, mimeType: String, title: String) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, "Exportación de $title (${file.name}) desde SYS-TF ERP.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(sendIntent, "Abrir o Guardar $title").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to share or open file: ${e.message}", e)
            try {
                Toast.makeText(context, "Archivo guardado en Descargas: ${file.name}", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {}
        }
    }

    fun getSampleCsvTemplate(): String {
        return """
        Nombre,Codigo,Categoria,Precio_Costo,Precio_Venta,Stock,Stock_Minimo,Descripcion
        Aceite Motor Sintético 10W-40,MOT-10W40,Lubricantes,32.50,48.00,24,5,Aceite sintético de alta protección para motor
        Filtro de Aire Premium,FIL-AIR-01,Filtros,15.00,25.00,18,4,Filtro de aire de alto flujo
        Pastillas de Freno Cerámicas,FRN-CER-02,Frenos,45.00,75.00,12,3,Juego de pastillas delanteras
        Batería 12V 65Ah Libre Mant.,BAT-65AH,Baterías,65.00,110.00,8,2,Batería sellada de arranque reforzado
        Bujía de Iridio NGK,BUJ-NGK-IR,Encendido,8.50,15.00,40,10,Bujía de larga duración alto encendido
        """.trimIndent()
    }

    private fun escapeCsv(text: String): String {
        return if (text.contains(",") || text.contains("\"") || text.contains("\n") || text.contains(";")) {
            "\"" + text.replace("\"", "\"\"") + "\""
        } else {
            text
        }
    }

    private fun escapeHtml(text: String): String {
        return text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
    }
}
