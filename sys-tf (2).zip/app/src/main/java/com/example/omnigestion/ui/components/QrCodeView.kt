package com.example.omnigestion.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.abs

@Composable
fun QrCodeView(
    data: String,
    modifier: Modifier = Modifier,
    sizeDp: Int = 200
) {
    Box(
        modifier = modifier
            .size(sizeDp.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        val qrPixelColor = MaterialTheme.colorScheme.onBackground
        Canvas(modifier = Modifier.size((sizeDp - 32).dp)) {
            val gridSize = 21
            val cellSize = size.width / gridSize
            val hash = abs(data.hashCode())
            for (row in 0 until gridSize) {
                for (col in 0 until gridSize) {
                    val isCornerFinder = (row < 7 && col < 7) || (row < 7 && col >= gridSize - 7) || (row >= gridSize - 7 && col < 7)
                    val isCornerFinderBorder = (row == 0 || row == 6 || col == 0 || col == 6) && (row < 7 && col < 7) ||
                            (row == 0 || row == 6 || col == gridSize - 7 || col == gridSize - 1) && (row < 7 && col >= gridSize - 7) ||
                            (row == gridSize - 7 || row == gridSize - 1 || col == 0 || col == 6) && (row >= gridSize - 7 && col < 7)
                    val isCornerCenter = (row in 2..4 && col in 2..4) ||
                            (row in 2..4 && col in gridSize - 5 until gridSize - 2) ||
                            (row in gridSize - 5 until gridSize - 2 && col in 2..4)
                    val bit = ((row * 31 + col * 17 + hash) % 3) == 0

                    val shouldDraw = if (isCornerFinder) {
                        isCornerFinderBorder || isCornerCenter
                    } else {
                        bit
                    }

                    if (shouldDraw) {
                        drawRect(
                            color = qrPixelColor,
                            topLeft = Offset(col * cellSize, row * cellSize),
                            size = Size(cellSize, cellSize)
                        )
                    }
                }
            }
        }
    }
}
