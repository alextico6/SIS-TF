package com.example.omnigestion.ui.screens.employees

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnigestion.data.model.Employee
import com.example.omnigestion.data.model.RoleType
import com.example.omnigestion.ui.components.omniTextFieldColors
import com.example.omnigestion.ui.viewmodel.OmniViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmployeesScreen(viewModel: OmniViewModel) {
    val employees by viewModel.employees.collectAsState()
    val attendances by viewModel.attendances.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()
    val sales by viewModel.sales.collectAsState()

    val isAdmin = currentRole == RoleType.ADMIN
    val isUserShiftActive = currentUser?.activeShiftStart != null

    var selectedTab by remember { mutableStateOf(0) }
    var showAddDialog by remember { mutableStateOf(false) }
    var employeeToEdit by remember { mutableStateOf<Employee?>(null) }
    var employeeToDelete by remember { mutableStateOf<Employee?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isUserShiftActive) EmeraldContainer else MaterialTheme.colorScheme.primaryContainer
            ),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (isUserShiftActive) EmeraldSuccess.copy(alpha = 0.5f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (isUserShiftActive) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isUserShiftActive) "Turno Activo: En servicio" else "Turno Fuera de Servicio",
                            fontWeight = FontWeight.Bold,
                            color = if (isUserShiftActive) Color(0xFF065F46) else MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text = "Usuario: ${currentUser?.fullName ?: "Colaborador"} (${currentUser?.role ?: "Admin"})",
                        fontSize = 12.sp,
                        color = if (isUserShiftActive) EmeraldSuccess else BlueAccent
                    )
                }
                Button(
                    onClick = {
                        if (isUserShiftActive) {
                            viewModel.clockOutAttendance()
                        } else {
                            viewModel.clockInAttendance()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isUserShiftActive) RoseDanger else EmeraldSuccess
                    ),
                    modifier = Modifier.testTag("employee_clock_button")
                ) {
                    Icon(
                        imageVector = if (isUserShiftActive) Icons.Default.Logout else Icons.Default.Login,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isUserShiftActive) "Marcar Salida" else "Marcar Entrada", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (isAdmin) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = {
                        employeeToEdit = null
                        showAddDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("employee_add_button")
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Nuevo Colaborador", fontSize = 12.sp)
                }
            }
        }

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp).clip(RoundedCornerShape(12.dp))
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Colaboradores", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Asistencia", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Comisiones", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
        }

        Spacer(modifier = Modifier.height(6.dp))

        when (selectedTab) {
            0 -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(employees, key = { it.id }) { emp ->
                        val empSales = sales.filter { it.employeeId == emp.id && it.paymentStatus != "ANULADO" }
                        val totalVendido = empSales.sumOf { it.totalAmount }
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when (emp.role) {
                                                    RoleType.ADMIN.name -> RoleAdminColor
                                                    RoleType.CAJERO.name -> RoleCashierColor
                                                    RoleType.CLIENTE.name -> RoleClientColor
                                                    else -> RoleEmployeeColor
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = emp.fullName.take(2).uppercase(),
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(emp.fullName, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant
                                            ) {
                                                Text(
                                                    text = emp.role,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                            Text("Tel: ${emp.phone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    if (isAdmin) {
                                        Row {
                                            IconButton(onClick = {
                                                employeeToEdit = emp
                                                showAddDialog = true
                                            }) {
                                                Icon(Icons.Default.Edit, contentDescription = "Editar", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                                            }
                                            IconButton(onClick = { employeeToDelete = emp }) {
                                                Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = RoseDanger, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Ventas: ${empSales.size} pedidos • Facturado: ${currency.symbol} ${String.format(Locale.US, "%.2f", totalVendido)}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(attendances) { att ->
                        val checkInStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(att.checkInTime))
                        val checkOutStr = att.checkOutTime?.let { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(it)) } ?: "En curso"
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(att.employeeName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Fecha: ${att.dateStr} • Entrada: $checkInStr | Salida: $checkOutStr", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (att.checkOutTime != null) EmeraldContainer else AmberContainer
                                ) {
                                    Text(
                                        text = if (att.checkOutTime != null) "${att.hoursWorked} hrs" else "En Turno",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = if (att.checkOutTime != null) EmeraldSuccess else AmberAccent,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(employees) { emp ->
                        val empSales = sales.filter { it.employeeId == emp.id && it.paymentStatus != "ANULADO" }
                        val totalVentas = empSales.sumOf { it.totalAmount }
                        val comision = totalVentas * (emp.commissionRate / 100.0)
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(emp.fullName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text("Sueldo Base: Bs ${String.format(Locale.US, "%.2f", emp.baseSalary)} • Tasa Comisión: ${emp.commissionRate}%", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Comisión Acumulada Mes:", fontSize = 12.sp)
                                    Text("Bs ${String.format(Locale.US, "%.2f", comision)}", fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Total Liquidación Estimada:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Bs ${String.format(Locale.US, "%.2f", emp.baseSalary + comision)}", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var fullName by remember { mutableStateOf(employeeToEdit?.fullName ?: "") }
        var email by remember { mutableStateOf(employeeToEdit?.email ?: "") }
        var phone by remember { mutableStateOf(employeeToEdit?.phone ?: "") }
        var address by remember { mutableStateOf(employeeToEdit?.address ?: "") }
        var role by remember { mutableStateOf(employeeToEdit?.role ?: RoleType.EMPLEADO.name) }
        var baseSalary by remember { mutableStateOf(employeeToEdit?.baseSalary?.toString() ?: "3000.0") }
        var commissionRate by remember { mutableStateOf(employeeToEdit?.commissionRate?.toString() ?: "5.0") }
        var password by remember { mutableStateOf(employeeToEdit?.password ?: "123456") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text(if (employeeToEdit == null) "Nuevo Colaborador" else "Editar Colaborador", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Nombre Completo") }, singleLine = true, colors = omniTextFieldColors())
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Correo Electrónico") }, singleLine = true, colors = omniTextFieldColors())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Teléfono") }, singleLine = true, modifier = Modifier.weight(1f), colors = omniTextFieldColors())
                        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Contraseña") }, singleLine = true, modifier = Modifier.weight(1f), colors = omniTextFieldColors())
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = baseSalary, onValueChange = { baseSalary = it }, label = { Text("Sueldo Base (Bs)") }, singleLine = true, modifier = Modifier.weight(1f), colors = omniTextFieldColors())
                        OutlinedTextField(value = commissionRate, onValueChange = { commissionRate = it }, label = { Text("% Comisión") }, singleLine = true, modifier = Modifier.weight(1f), colors = omniTextFieldColors())
                    }
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Dirección / Sucursal") }, singleLine = true, colors = omniTextFieldColors())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (fullName.isNotBlank()) {
                            val emp = Employee(
                                id = employeeToEdit?.id ?: UUID.randomUUID().toString(),
                                fullName = fullName,
                                email = email,
                                phone = phone,
                                address = address,
                                role = role,
                                baseSalary = baseSalary.toDoubleOrNull() ?: 3000.0,
                                commissionRate = commissionRate.toDoubleOrNull() ?: 5.0,
                                password = password.ifBlank { "123456" }
                            )
                            viewModel.saveEmployee(emp)
                            showAddDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Guardar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    employeeToDelete?.let { emp ->
        AlertDialog(
            onDismissRequest = { employeeToDelete = null },
            title = { Text("¿Eliminar a ${emp.fullName}?", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    text = "Esta acción eliminará al colaborador de la plantilla y revocará su acceso a SYS-TF.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteEmployee(emp)
                        employeeToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseDanger)
                ) {
                    Text("Eliminar Definitivamente")
                }
            },
            dismissButton = {
                TextButton(onClick = { employeeToDelete = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}
