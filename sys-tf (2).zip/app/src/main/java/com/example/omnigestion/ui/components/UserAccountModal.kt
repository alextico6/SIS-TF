package com.example.omnigestion.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnigestion.data.firebase.FirestoreSyncStatus
import com.example.omnigestion.data.model.Employee
import com.example.omnigestion.data.model.RoleType
import com.example.ui.theme.*

@Composable
fun UserAccountModal(
    currentUser: Employee?,
    currentRole: RoleType,
    syncStatus: FirestoreSyncStatus,
    onDismiss: () -> Unit,
    onTriggerSync: () -> Unit,
    onOpenSwitchUser: () -> Unit,
    onOpenSettings: () -> Unit,
    onLogout: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(
                            when (currentRole) {
                                RoleType.ADMIN -> RoleAdminColor
                                RoleType.EMPLEADO -> RoleEmployeeColor
                                RoleType.CAJERO -> RoleCashierColor
                                RoleType.CLIENTE -> RoleClientColor
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = (currentUser?.fullName ?: "U").take(2).uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = currentUser?.fullName ?: "Usuario",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = when (currentRole) {
                            RoleType.ADMIN -> RoleAdminContainer
                            RoleType.EMPLEADO -> RoleEmployeeContainer
                            RoleType.CAJERO -> RoleCashierContainer
                            RoleType.CLIENTE -> RoleClientContainer
                        }
                    ) {
                        Text(
                            text = "Rol: ${currentRole.title}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (currentRole) {
                                RoleType.ADMIN -> RoleAdminColor
                                RoleType.EMPLEADO -> RoleEmployeeColor
                                RoleType.CAJERO -> RoleCashierColor
                                RoleType.CLIENTE -> RoleClientColor
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Cloud Sync Status & Action
                Surface(
                    onClick = onTriggerSync,
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.CloudSync,
                                contentDescription = null,
                                tint = if (syncStatus.isSyncing) AmberAccent else EmeraldSuccess,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Sincronización en la Nube", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(
                                    text = if (syncStatus.isSyncing) "Sincronizando..." else "Conectado y Actualizado",
                                    fontSize = 11.sp,
                                    color = if (syncStatus.isSyncing) AmberAccent else EmeraldSuccess
                                )
                            }
                        }
                        Text("Sincronizar", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlueAccent)
                    }
                }

                // Switch User (Only for internal staff: Admin, Empleado, Cajero - NEVER for clients)
                if (currentRole != RoleType.CLIENTE) {
                    OutlinedButton(
                        onClick = onOpenSwitchUser,
                        modifier = Modifier.fillMaxWidth().height(42.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.SwitchAccount, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Cambiar de Cuenta / Colaborador", fontSize = 12.sp)
                    }
                }

                if (currentRole == RoleType.ADMIN) {
                    OutlinedButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.fillMaxWidth().height(42.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Configuración de la Empresa", fontSize = 12.sp)
                    }
                }

                // Logout Button
                Button(
                    onClick = onLogout,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth().height(42.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Cerrar Sesión", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cerrar", fontWeight = FontWeight.Bold)
            }
        }
    )
}
