package com.example.omnigestion.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.omnigestion.data.local.AppDatabase
import com.example.omnigestion.data.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class CartItem(
    val product: Product,
    val quantity: Int,
    val unitPrice: Double
) {
    val subtotal: Double get() = quantity * unitPrice
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val productDao = db.productDao()
    private val saleDao = db.saleDao()
    private val expenseDao = db.expenseDao()
    private val customerDao = db.customerDao()
    private val employeeDao = db.employeeDao()
    private val purchaseOrderDao = db.purchaseOrderDao()
    private val settingsDao = db.settingsDao()

    val products: StateFlow<List<Product>> = productDao.getAllProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sales: StateFlow<List<Sale>> = saleDao.getAllSales()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenses: StateFlow<List<Expense>> = expenseDao.getAllExpenses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customers: StateFlow<List<Customer>> = customerDao.getAllCustomers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val employees: StateFlow<List<Employee>> = employeeDao.getAllEmployees()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val purchaseOrders: StateFlow<List<PurchaseOrder>> = purchaseOrderDao.getAllOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<BusinessSettings> = settingsDao.getSettings()
        .map { it ?: BusinessSettings() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BusinessSettings())

    // Active User
    private val _currentUser = MutableStateFlow(
        Employee("EMP-001", "Alex Ticona Flores", RoleType.ADMIN.name, "alex.ticona@sys-tf.bo", "1234")
    )
    val currentUser: StateFlow<Employee> = _currentUser.asStateFlow()

    fun switchUser(employee: Employee) {
        _currentUser.value = employee
    }

    // POS Cart
    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _selectedCustomer = MutableStateFlow<Customer?>(null)
    val selectedCustomer: StateFlow<Customer?> = _selectedCustomer.asStateFlow()

    private val _lastSaleReceipt = MutableStateFlow<Sale?>(null)
    val lastSaleReceipt: StateFlow<Sale?> = _lastSaleReceipt.asStateFlow()

    fun selectCustomer(customer: Customer?) {
        _selectedCustomer.value = customer
    }

    fun clearLastReceipt() {
        _lastSaleReceipt.value = null
    }

    fun addToCart(product: Product) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id }
        if (index != -1) {
            val item = current[index]
            if (item.quantity < product.stockQuantity) {
                current[index] = item.copy(quantity = item.quantity + 1)
            }
        } else {
            if (product.stockQuantity > 0) {
                current.add(CartItem(product, 1, product.salePrice))
            }
        }
        _cart.value = current
    }

    fun updateCartQuantity(productId: String, newQty: Int) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == productId }
        if (index != -1) {
            if (newQty <= 0) {
                current.removeAt(index)
            } else {
                val item = current[index]
                val max = item.product.stockQuantity
                val finalQty = if (newQty > max) max else newQty
                current[index] = item.copy(quantity = finalQty)
            }
            _cart.value = current
        }
    }

    fun removeFromCart(productId: String) {
        _cart.value = _cart.value.filterNot { it.product.id == productId }
    }

    fun clearCart() {
        _cart.value = emptyList()
        _selectedCustomer.value = null
    }

    fun completeSale(paymentMethod: String, onFinished: (Sale) -> Unit) {
        val cartItems = _cart.value
        if (cartItems.isEmpty()) return

        val total = cartItems.sumOf { it.subtotal }
        val saleId = "VTA-" + System.currentTimeMillis().toString().takeLast(6)
        val customer = _selectedCustomer.value
        val sale = Sale(
            id = saleId,
            timestamp = System.currentTimeMillis(),
            totalAmount = total,
            paymentMethod = paymentMethod,
            customerName = customer?.name ?: "Cliente Mostrador",
            customerNit = customer?.nit ?: "0",
            invoiceNumber = "FAC-" + System.currentTimeMillis().toString().takeLast(5),
            sellerName = _currentUser.value.name
        )

        viewModelScope.launch {
            saleDao.insertSale(sale)

            val saleItems = cartItems.map { item ->
                SaleItem(
                    id = UUID.randomUUID().toString(),
                    saleId = saleId,
                    productId = item.product.id,
                    productName = item.product.name,
                    quantity = item.quantity,
                    unitPrice = item.unitPrice,
                    costPrice = item.product.costPrice,
                    subtotal = item.subtotal
                )
            }
            saleDao.insertSaleItems(saleItems)

            // Decrement stock
            cartItems.forEach { item ->
                val updatedStock = (item.product.stockQuantity - item.quantity).coerceAtLeast(0)
                productDao.updateProduct(item.product.copy(stockQuantity = updatedStock))
            }

            // Update customer debt if credit
            if (paymentMethod == "Crédito" && customer != null) {
                customerDao.updateCustomer(customer.copy(currentDebt = customer.currentDebt + total))
            }

            _cart.value = emptyList()
            _selectedCustomer.value = null
            _lastSaleReceipt.value = sale
            onFinished(sale)
        }
    }

    // Product CRUD
    fun saveProduct(product: Product) {
        viewModelScope.launch {
            productDao.insertProduct(product)
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            productDao.deleteProduct(product)
        }
    }

    fun adjustStock(product: Product, delta: Int) {
        viewModelScope.launch {
            val newQty = (product.stockQuantity + delta).coerceAtLeast(0)
            productDao.updateProduct(product.copy(stockQuantity = newQty))
        }
    }

    // Purchase Registration / Multi-Product Purchase Expense
    fun registerProductPurchase(
        supplierName: String,
        receiptVoucher: String,
        paymentMethod: String,
        notes: String,
        items: List<PurchaseOrderItemInput>,
        updateCatalogPrices: Boolean,
        onSuccess: () -> Unit
    ) {
        if (items.isEmpty()) return

        val totalAmount = items.sumOf { it.quantity * it.purchasePrice }
        val orderNumber = "OC-" + System.currentTimeMillis().toString().takeLast(5)
        val orderId = UUID.randomUUID().toString()

        val summaryDetails = items.joinToString(", ") { "${it.quantity}x ${it.product.name}" }

        val expense = Expense(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            amount = totalAmount,
            category = ExpenseCategory.COMPRAS_PRODUCTOS.name,
            description = if (notes.isNotBlank()) notes else "Compra de mercadería a $supplierName",
            supplierName = supplierName,
            receiptVoucher = receiptVoucher,
            paymentMethod = paymentMethod,
            isProductPurchase = true,
            purchaseItemsDetails = summaryDetails
        )

        val purchaseOrder = PurchaseOrder(
            id = orderId,
            timestamp = System.currentTimeMillis(),
            orderNumber = orderNumber,
            supplierName = supplierName,
            supplierPhone = "",
            totalAmount = totalAmount,
            status = "RECIBIDO",
            notes = notes
        )

        val orderItems = items.map { item ->
            PurchaseOrderItem(
                id = UUID.randomUUID().toString(),
                orderId = orderId,
                productId = item.product.id,
                productName = item.product.name,
                quantity = item.quantity,
                unitCost = item.purchasePrice,
                unitSale = item.salePrice,
                subtotal = item.quantity * item.purchasePrice
            )
        }

        viewModelScope.launch {
            expenseDao.insertExpense(expense)
            purchaseOrderDao.insertOrder(purchaseOrder)
            purchaseOrderDao.insertOrderItems(orderItems)

            // Update inventory stock and optionally catalog prices
            items.forEach { input ->
                val p = productDao.getProductById(input.product.id) ?: input.product
                val updatedStock = p.stockQuantity + input.quantity
                val updatedCost = if (updateCatalogPrices) input.purchasePrice else p.costPrice
                val updatedSale = if (updateCatalogPrices) input.salePrice else p.salePrice

                productDao.updateProduct(
                    p.copy(
                        stockQuantity = updatedStock,
                        costPrice = updatedCost,
                        salePrice = updatedSale
                    )
                )
            }

            onSuccess()
        }
    }

    // General Expense CRUD
    fun saveExpense(expense: Expense) {
        viewModelScope.launch {
            expenseDao.insertExpense(expense)
        }
    }

    fun updateExpense(expense: Expense) {
        viewModelScope.launch {
            expenseDao.updateExpense(expense)
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            expenseDao.deleteExpense(expense)
        }
    }

    // Customer CRUD
    fun saveCustomer(customer: Customer) {
        viewModelScope.launch {
            customerDao.insertCustomer(customer)
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            customerDao.deleteCustomer(customer)
        }
    }

    fun registerDebtPayment(customerId: String, amount: Double, paymentMethod: String, receipt: String) {
        viewModelScope.launch {
            val payment = DebtPayment(
                id = UUID.randomUUID().toString(),
                customerId = customerId,
                timestamp = System.currentTimeMillis(),
                amountPaid = amount,
                paymentMethod = paymentMethod,
                receiptNumber = receipt
            )
            customerDao.insertDebtPayment(payment)

            val customersList = customerDao.getAllCustomersSync()
            val customer = customersList.find { it.id == customerId }
            if (customer != null) {
                val newDebt = (customer.currentDebt - amount).coerceAtLeast(0.0)
                customerDao.updateCustomer(customer.copy(currentDebt = newDebt))
            }
        }
    }

    // Settings
    fun updateSettings(newSettings: BusinessSettings) {
        viewModelScope.launch {
            settingsDao.saveSettings(newSettings)
        }
    }

    // Employees
    fun saveEmployee(employee: Employee) {
        viewModelScope.launch {
            employeeDao.insertEmployee(employee)
        }
    }

    fun deleteEmployee(employee: Employee) {
        viewModelScope.launch {
            employeeDao.deleteEmployee(employee)
        }
    }
}
