package com.example.omnigestion.ui.screens.sales

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnigestion.data.model.PaymentMethod
import com.example.omnigestion.data.model.RoleType
import com.example.omnigestion.data.model.Sale
import com.example.omnigestion.data.model.SaleItem
import com.example.omnigestion.data.pdf.PdfReportGenerator
import com.example.omnigestion.ui.components.omniTextFieldColors
import com.example.omnigestion.ui.viewmodel.OmniViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesHistoryScreen(viewModel: OmniViewModel) {
    val context = LocalContext.current
    val sales by viewModel.sales.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()
    val customers by viewModel.customers.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterPeriod by remember { mutableStateOf("TODOS") } // HOY, 7_DIAS, MES, TODOS
    var selectedPaymentFilter by remember { mutableStateOf("TODOS") }
    var selectedStatusFilter by remember { mutableStateOf("TODOS") }

    var saleToEdit by remember { mutableStateOf<Sale?>(null) }
    var saleToVoid by remember { mutableStateOf<Sale?>(null) }
    var saleToDelete by remember { mutableStateOf<Sale?>(null) }

    val calendar = remember { Calendar.getInstance() }
    val now = System.currentTimeMillis()

    val filteredSales = remember(sales, searchQuery, selectedFilterPeriod, selectedPaymentFilter, selectedStatusFilter) {
        sales.filter { sale ->
            val matchesSearch = searchQuery.isBlank() ||
                    sale.saleNumber.contains(searchQuery, ignoreCase = true) ||
                    sale.customerName.contains(searchQuery, ignoreCase = true) ||
                    sale.employeeName.contains(searchQuery, ignoreCase = true)

            val matchesPayment = selectedPaymentFilter == "TODOS" || sale.paymentMethod == selectedPaymentFilter
            val matchesStatus = selectedStatusFilter == "TODOS" || sale.paymentStatus == selectedStatusFilter

            val matchesPeriod = when (selectedFilterPeriod) {
                "HOY" -> {
                    calendar.timeInMillis = now
                    val todayYear = calendar.get(Calendar.YEAR)
                    val todayDay = calendar.get(Calendar.DAY_OF_YEAR)
                    calendar.timeInMillis = sale.timestamp
                    calendar.get(Calendar.YEAR) == todayYear && calendar.get(Calendar.DAY_OF_YEAR) == todayDay
                }
                "7_DIAS" -> (now - sale.timestamp) <= 7 * 24 * 60 * 60 * 1000L
                "MES" -> {
                    calendar.timeInMillis = now
                    val thisMonth = calendar.get(Calendar.MONTH)
                    val thisYear = calendar.get(Calendar.YEAR)
                    calendar.timeInMillis = sale.timestamp
                    calendar.get(Calendar.YEAR) == thisYear && calendar.get(Calendar.MONTH) == thisMonth
                }
                else -> true
            }

            matchesSearch && matchesPayment && matchesStatus && matchesPeriod
        }.sortedByDescending { it.timestamp }
    }

    val totalAmountFiltered = remember(filteredSales) {
        filteredSales.filter { it.paymentStatus != "ANULADO" }.sumOf { it.totalAmount }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Search & Filter Header
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Historial de Ventas", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(
                                text = "${filteredSales.size} ventas • Total: ${currency.symbol} ${String.format(Locale.US, "%.2f", totalAmountFiltered)}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth().testTag("sales_search_input"),
                        placeholder = { Text("Buscar por N° Venta, cliente o vendedor...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Limpiar")
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = omniTextFieldColors(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Period Quick Filters
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "TODOS" to "Todo",
                            "HOY" to "Hoy",
                            "7_DIAS" to "7 Días",
                            "MES" to "Este Mes"
                        ).forEach { (key, label) ->
                            FilterChip(
                                selected = selectedFilterPeriod == key,
                                onClick = { selectedFilterPeriod = key },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        }

        if (filteredSales.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 30.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.Gray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No se encontraron ventas con estos filtros", color = Color.Gray, fontSize = 14.sp)
                    }
                }
            }
        } else {
            items(filteredSales, key = { it.id }) { sale ->
                SaleHistoryCard(
                    sale = sale,
                    currencySymbol = currency.symbol,
                    canAdmin = currentRole == RoleType.ADMIN,
                    onViewReceipt = {
                        val file = viewModel.exportSaleReceiptPdf(sale)
                        if (file != null) {
                            PdfReportGenerator.openOrSharePdf(context, file, "Recibo de Venta ${sale.saleNumber}")
                        }
                    },
                    onEdit = { saleToEdit = sale },
                    onVoid = { saleToVoid = sale },
                    onDeletePermanent = { saleToDelete = sale },
                    viewModel = viewModel
                )
            }
        }
    }

    // Modal: Edit Sale
    saleToEdit?.let { sale ->
        EditSaleDialog(
            sale = sale,
            viewModel = viewModel,
            currencySymbol = currency.symbol,
            onDismiss = { saleToEdit = null }
        )
    }

    // Modal: Void Sale Confirmation
    saleToVoid?.let { sale ->
        AlertDialog(
            onDismissRequest = { saleToVoid = null },
            title = { Text("¿Anular Venta ${sale.saleNumber}?") },
            text = {
                Text("Esta acción restaurará el stock de los productos vendidos a su almacén original y marcará la venta como ANULADA.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.voidSale(sale.id)
                        saleToVoid = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseDanger)
                ) {
                    Text("Sí, Anular Venta")
                }
            },
            dismissButton = {
                TextButton(onClick = { saleToVoid = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Modal: Delete Permanent Confirmation
    saleToDelete?.let { sale ->
        AlertDialog(
            onDismissRequest = { saleToDelete = null },
            title = { Text("¿Eliminar Definitivamente?") },
            text = {
                Text("Esta acción eliminará de forma irreversible el registro de la venta ${sale.saleNumber}. Esta acción es solo para administradores.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteSalePermanent(sale.id)
                        saleToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseDanger)
                ) {
                    Text("Eliminar Registro")
                }
            },
            dismissButton = {
                TextButton(onClick = { saleToDelete = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun SaleHistoryCard(
    sale: Sale,
    currencySymbol: String,
    canAdmin: Boolean,
    onViewReceipt: () -> Unit,
    onEdit: () -> Unit,
    onVoid: () -> Unit,
    onDeletePermanent: () -> Unit,
    viewModel: OmniViewModel
) {
    var expanded by remember { mutableStateOf(false) }
    var itemsList by remember { mutableStateOf<List<SaleItem>?>(null) }
    val scope = rememberCoroutineScope()

    val dateFormatted = remember(sale.timestamp) {
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(sale.timestamp))
    }

    val isAnulado = sale.paymentStatus == "ANULADO"
    val isCredito = sale.paymentMethod == PaymentMethod.CREDITO.name || sale.paymentStatus == "A_CREDITO"

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isAnulado) MaterialTheme.colorScheme.surface.copy(alpha = 0.6f) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isAnulado -> RoseDanger.copy(alpha = 0.15f)
                                    isCredito -> AmberWarning.copy(alpha = 0.15f)
                                    sale.paymentMethod == PaymentMethod.QR_BANCARIO.name -> BlueAccent.copy(alpha = 0.15f)
                                    else -> EmeraldSuccess.copy(alpha = 0.15f)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when {
                                isAnulado -> Icons.Default.Block
                                isCredito -> Icons.Default.CreditCard
                                sale.paymentMethod == PaymentMethod.QR_BANCARIO.name -> Icons.Default.QrCode
                                else -> Icons.Default.AttachMoney
                            },
                            contentDescription = null,
                            tint = when {
                                isAnulado -> RoseDanger
                                isCredito -> AmberWarning
                                sale.paymentMethod == PaymentMethod.QR_BANCARIO.name -> BlueAccent
                                else -> EmeraldSuccess
                            },
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(sale.saleNumber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(dateFormatted, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "$currencySymbol ${String.format(Locale.US, "%.2f", sale.totalAmount)}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        color = if (isAnulado) Color.Gray else MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when {
                            isAnulado -> RoseDanger.copy(alpha = 0.15f)
                            isCredito -> AmberWarning.copy(alpha = 0.15f)
                            else -> EmeraldSuccess.copy(alpha = 0.15f)
                        }
                    ) {
                        Text(
                            text = when {
                                isAnulado -> "ANULADA"
                                isCredito -> "A CRÉDITO"
                                else -> "PAGADO"
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                isAnulado -> RoseDanger
                                isCredito -> AmberWarning
                                else -> EmeraldSuccess
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Cliente: ${sale.customerName}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Vendedor: ${sale.employeeName}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (sale.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Nota: ${sale.notes}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Expand / Collapse Items Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        expanded = !expanded
                        if (expanded && itemsList == null) {
                            scope.launch {
                                itemsList = viewModel.getSaleItems(sale.id)
                            }
                        }
                    }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (expanded) "Ocultar detalles" else "Ver detalle de productos",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    val items = itemsList
                    if (items == null) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp).align(Alignment.CenterHorizontally))
                    } else if (items.isEmpty()) {
                        Text("No hay detalles disponibles para esta venta.", fontSize = 11.sp, color = Color.Gray)
                    } else {
                        items.forEach { item ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${item.quantity}x ${item.productName}",
                                    fontSize = 12.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "$currencySymbol ${String.format(Locale.US, "%.2f", item.subtotal)}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onViewReceipt, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Print, contentDescription = "Imprimir Recibo", tint = MaterialTheme.colorScheme.primary)
                }

                if (!isAnulado && canAdmin) {
                    IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Editar Venta", tint = BlueAccent)
                    }

                    IconButton(onClick = onVoid, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Undo, contentDescription = "Anular Venta", tint = AmberWarning)
                    }
                }

                if (canAdmin) {
                    IconButton(onClick = onDeletePermanent, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Eliminar Registro", tint = RoseDanger)
                    }
                }
            }
        }
    }
}

@Composable
fun EditSaleDialog(
    sale: Sale,
    viewModel: OmniViewModel,
    currencySymbol: String,
    onDismiss: () -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    var selectedCustomerId by remember { mutableStateOf(sale.customerId) }
    var selectedPaymentMethod by remember { mutableStateOf(sale.paymentMethod) }
    var notes by remember { mutableStateOf(sale.notes) }
    var itemsList by remember { mutableStateOf<List<SaleItem>>(emptyList()) }
    var isLoadingItems by remember { mutableStateOf(true) }

    LaunchedEffect(sale.id) {
        itemsList = viewModel.getSaleItems(sale.id)
        isLoadingItems = false
    }

    val totalAmount = remember(itemsList) {
        itemsList.sumOf { it.subtotal }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Modificar Venta ${sale.saleNumber}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Método de Pago", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PaymentMethod.entries.forEach { method ->
                            FilterChip(
                                selected = selectedPaymentMethod == method.name,
                                onClick = { selectedPaymentMethod = method.name },
                                label = { Text(method.title, fontSize = 10.sp) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notas de la venta") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = omniTextFieldColors()
                    )
                }

                item {
                    Text("Productos en la Venta", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                if (isLoadingItems) {
                    item {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp).padding(8.dp))
                    }
                } else {
                    items(itemsList) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.productName, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    Text(
                                        "${currencySymbol} ${String.format(Locale.US, "%.2f", item.unitPrice)} c/u",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = {
                                            if (item.quantity > 1) {
                                                val newQty = item.quantity - 1
                                                itemsList = itemsList.map {
                                                    if (it.id == item.id) it.copy(quantity = newQty, subtotal = newQty * it.unitPrice) else it
                                                }
                                            }
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Menos", modifier = Modifier.size(20.dp))
                                    }
                                    Text("${item.quantity}", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 6.dp))
                                    IconButton(
                                        onClick = {
                                            val newQty = item.quantity + 1
                                            itemsList = itemsList.map {
                                                if (it.id == item.id) it.copy(quantity = newQty, subtotal = newQty * it.unitPrice) else it
                                            }
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.AddCircleOutline, contentDescription = "Más", modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Total recalculado:", fontWeight = FontWeight.Bold)
                        Text(
                            "$currencySymbol ${String.format(Locale.US, "%.2f", totalAmount)}",
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val customer = customers.firstOrNull { it.id == selectedCustomerId }
                    val custName = customer?.name ?: sale.customerName
                    val updatedSale = sale.copy(
                        customerId = selectedCustomerId,
                        customerName = custName,
                        paymentMethod = selectedPaymentMethod,
                        paymentStatus = if (selectedPaymentMethod == PaymentMethod.CREDITO.name) "A_CREDITO" else "PAGADO",
                        totalAmount = totalAmount,
                        notes = notes
                    )
                    viewModel.updateSale(updatedSale, itemsList)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Guardar Cambios")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
