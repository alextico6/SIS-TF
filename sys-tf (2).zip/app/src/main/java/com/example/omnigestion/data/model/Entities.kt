package com.example.omnigestion.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val id: String,
    val name: String,
    val sku: String,
    val category: String,
    val costPrice: Double,
    val salePrice: Double,
    val stockQuantity: Int,
    val minStock: Int = 5,
    val imageUrl: String? = null
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val totalAmount: Double,
    val paymentMethod: String,
    val customerName: String = "Cliente General",
    val customerNit: String = "0",
    val invoiceNumber: String,
    val sellerName: String = "Cajero Principal"
)

@Entity(tableName = "sale_items")
data class SaleItem(
    @PrimaryKey val id: String,
    val saleId: String,
    val productId: String,
    val productName: String,
    val quantity: Int,
    val unitPrice: Double,
    val costPrice: Double = 0.0,
    val subtotal: Double
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val amount: Double,
    val category: String,
    val description: String,
    val supplierName: String = "",
    val receiptVoucher: String = "",
    val paymentMethod: String = "Efectivo",
    val isProductPurchase: Boolean = false,
    val purchaseItemsDetails: String = ""
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String = "",
    val nit: String = "",
    val address: String = "",
    val creditLimit: Double = 1000.0,
    val currentDebt: Double = 0.0
)

@Entity(tableName = "debt_payments")
data class DebtPayment(
    @PrimaryKey val id: String,
    val customerId: String,
    val timestamp: Long,
    val amountPaid: Double,
    val paymentMethod: String = "Efectivo",
    val receiptNumber: String = ""
)

@Entity(tableName = "employees")
data class Employee(
    @PrimaryKey val id: String,
    val name: String,
    val role: String,
    val email: String,
    val pin: String = "1234",
    val phone: String = ""
)

@Entity(tableName = "purchase_orders")
data class PurchaseOrder(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val orderNumber: String,
    val supplierName: String,
    val supplierPhone: String = "",
    val totalAmount: Double,
    val status: String = "RECIBIDO",
    val notes: String = ""
)

@Entity(tableName = "purchase_order_items")
data class PurchaseOrderItem(
    @PrimaryKey val id: String,
    val orderId: String,
    val productId: String,
    val productName: String,
    val quantity: Int,
    val unitCost: Double,
    val unitSale: Double,
    val subtotal: Double
)

data class PurchaseOrderItemInput(
    val product: Product,
    val quantity: Int,
    val purchasePrice: Double,
    val salePrice: Double
)

@Entity(tableName = "business_settings")
data class BusinessSettings(
    @PrimaryKey val id: String = "default_settings",
    val businessName: String = "SYS-TF",
    val taxId: String = "NIT: 102938475",
    val phone: String = "+591 70011223",
    val email: String = "contacto@sys-tf.bo",
    val address: String = "Av. Principal #123",
    val slogan: String = "Tecnología y Ferretería a tu Alcance",
    val logoUrl: String? = null,
    val currencySymbol: String = "Bs",
    val taxPercentage: Double = 13.0,
    val invoicePrefix: String = "FAC-",
    val receiptFooterMessage: String = "¡Gracias por su compra! Vuelva pronto.",
    val bankAccount: String = "1000-2938-4829",
    val bankName: String = "Banco Unión",
    val qrHolderName: String = "Alex Ticona Flores"
)

enum class RoleType(val displayName: String) {
    ADMIN("Administrador"),
    GERENTE("Gerente"),
    CAJERO("Cajero"),
    VENDEDOR("Vendedor"),
    BODEGUERO("Bodeguero")
}

enum class ExpenseCategory(val title: String) {
    COMPRAS_PRODUCTOS("Compra de Mercadería"),
    GASTOS_LOGISTICOS("Gastos Logísticos / Fletes"),
    GASTOS_PERSONALES("Sueldos y Personal"),
    OTROS_GASTOS("Servicios y Varios")
}
